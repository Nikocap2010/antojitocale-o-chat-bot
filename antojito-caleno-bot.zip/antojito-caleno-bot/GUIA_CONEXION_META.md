# Guía de Conexión y Despliegue — Antojito caleño (`+56 9 3054 3674`)

Este proyecto deja listo tu asistente de pedidos por WhatsApp para **Antojito caleño**, configurado con:
- **Modalidad:** Solo retiro en local (`Valdivia 1120, Tierras Blancas, Coquimbo`)
- **Pagos:** Efectivo y Transferencia (sin datos bancarios automáticos por ahora; editables luego desde el panel)
- **Menú y precios actualizados:**
  - Papas Chicas: `$2.500`
  - Papas Grande: `$3.500`
  - Completo: `$2.200` *(actualizado)*
  - Salchipapa Chica Tradicional: `$3.000`
  - Salchipapa Grande Tradicional: `$4.000`
  - Salchipapa Especial Personal *(lechuga, papa salchicha, papa hilo, pollo desmechado, costilla en salsa barbecue, queso y salsa de la casa)*: `$6.500`
  - Salchipapa Especial Grande *(mismos ingredientes)*: `$12.000`
  - Empanada de Queso: `$1.300` *(actualizado)*
  - Empanada (Día Fritanga): `$1.300`
  - Arepa con Chicharrón: `$4.800`
  - Aborrajado: `$2.500`
  - Coca-Cola 1 Litro: `$1.500`
  - Limón Soda 1 Litro: `$1.500`
  - Kem 1 Litro: `$1.500`
  - Pony Malta: `$1.800`
  - Postobón 400 ml: `$1.500`
  - Postobón 1,5 Litros: `$2.800`

---

## 1. Desplegar el servidor 24/7 (con HTTPS)

Meta necesita una URL pública **HTTPS** disponible todo el día para enviarte los mensajes que lleguen a `+56 9 3054 3674`.

Opciones recomendadas y económicas:
- **Railway / Render / Fly.io:** Sube la carpeta `antojito-caleno-bot` a un repositorio privado de GitHub y despliégala como servicio Node.js (`npm start`) o Docker (`Dockerfile` incluido).
- **VPS propio (Ubuntu + Docker / PM2 + Nginx o Caddy para HTTPS):**
  ```bash
  cp .env.example .env
  # Edita .env con tus credenciales
  npm install
  npm start
  ```

> **Nota sobre persistencia:** Si despliegas en Render o Railway, monta un volumen persistente en la carpeta `/app/data` para conservar tus pedidos, chats y cambios del menú entre reinicios.

---

## 2. Conectar `+56 9 3054 3674` a la API Oficial de Meta

Al usar **WhatsApp Business** actualmente en ese número, tienes dos caminos oficiales:

### Camino A — Meta Cloud API directo (sin intermediarios)
1. Entra a [Meta for Developers](https://developers.facebook.com/) → **Crear App** → tipo **Negocios (Business)** → agrega el producto **WhatsApp**.
2. En **WhatsApp > Configuración de la API**, agrega el número `+56 9 3054 3674` y verifícalo por SMS o llamada.
   - *Importante:* Al migrar un número directamente en Meta Developers, ese número deja de usarse en la app WhatsApp Business del celular. Para ver y responder los chats manualmente cuando necesites, usas la pestaña **Pedidos e Inbox** de este mismo panel web.
3. Crea un **System User Token** permanente en Meta Business Suite con permisos `whatsapp_business_messaging` y `whatsapp_business_management`.
4. Copia los valores en tu archivo `.env` del servidor:
   - `META_ACCESS_TOKEN`: el token permanente.
   - `META_PHONE_NUMBER_ID`: el *Identificador de número de teléfono* que aparece en Meta Developers (no es el `+569...`).
   - `META_VERIFY_TOKEN`: una clave secreta elegida por ti (ej. `antojito_caleno_verify_2026`).
   - `META_APP_SECRET`: el *Secreto de la aplicación* en Configuración Básica de tu app Meta (para validar firmas `X-Hub-Signature-256`).
5. En Meta Developers → **WhatsApp > Configuración > Webhook**:
   - **URL de devolución de llamada:** `https://tu-dominio.com/webhook`
   - **Token de verificación:** el mismo de `META_VERIFY_TOKEN`.
   - Haz clic en **Verificar y guardar** y suscríbete al campo **`messages`**.

### Camino B — Coexistencia oficial (Mantener la app WhatsApp Business en tu celular + IA a la vez)
Si quieres seguir viendo y respondiendo chats desde la app **WhatsApp Business** en tu teléfono mientras el bot responde en el mismo número:
1. En Meta, el modo **Coexistencia** requiere realizar el alta (*Embedded Signup*) a través de un **Tech Provider / BSP autorizado por Meta** compatible con Coexistencia en Chile (por ejemplo 360dialog, Dualhook u otro proveedor compatible).
2. Apunta el webhook de ese proveedor a `https://tu-dominio.com/webhook` y suscribe también `smb_message_echoes`.
3. Este servidor ya detecta los ecos cuando respondes manualmente desde tu celular y **pausa la IA automáticamente por 30 minutos** en ese chat para no interrumpirte.

---

## 3. Motor de IA (Local incluido vs LLM externo)

- **Sin costo extra (incluido):** El servidor trae un motor en español chileno que entiende saludos, pedidos combinados, aclaraciones (*Salchipapa Tradicional vs Especial*, *Papas Chicas vs Grande*), notas (*"sin lechuga"*), calcula totales exactos en CLP y toma nombre + medio de pago.
- **Con IA generativa (opcional):** Si agregas `LLM_API_KEY` en `.env` (compatible con OpenAI, Groq, OpenRouter, etc.), el bot responderá con conversación aún más libre, **pero el servidor seguirá validando precios y calculando los totales en código** para evitar errores de cálculo o inventos de platos.

---

## 4. Checklist antes de abrir al público

- [ ] Completar **Horario de atención** en la pestaña **Menú y Local**.
- [ ] Revisar si dejar activos los platos de **Día Fritanga** (*Arepa con Chicharrón*, *Aborrajado*, *Empanada Día Fritanga*) o pausarlos según el día.
- [ ] Definir si más adelante agregarás **Datos de transferencia** automáticos.
- [ ] Configurar `ADMIN_PASSWORD` en `.env` antes de publicar la URL del panel en internet.
