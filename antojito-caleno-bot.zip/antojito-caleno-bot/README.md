# Antojito caleño — Bot de Pedidos por WhatsApp

Asistente de pedidos por WhatsApp conectado a la **API Oficial de Meta (Cloud API)** para **Antojito caleño** (`+56 9 3054 3674`), configurado para **solo retiro en local** (`Valdivia 1120, Tierras Blancas, Coquimbo`) y pagos en **efectivo o transferencia**.

## Inicio rápido

```bash
npm install
cp .env.example .env
npm start
```

Luego abre `http://localhost:3000` en tu navegador para ver:
- **Simulador WhatsApp** para probar conversaciones y pedidos
- **Pedidos e Inbox** para gestionar pedidos y pausar la IA cuando respondas manualmente
- **Menú y Local** para actualizar precios, disponibilidad, horario y datos de transferencia
- **Guía Meta API** con prueba de webhook integrada

## Pruebas automatizadas

```bash
npm test
```

## Conexión a Meta y despliegue 24/7

Revisa las instrucciones paso a paso en **[GUIA_CONEXION_META.md](./GUIA_CONEXION_META.md)**.
