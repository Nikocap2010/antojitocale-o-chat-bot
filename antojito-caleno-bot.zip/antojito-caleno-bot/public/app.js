const SIM_CHAT_ID = 'sim-cliente-1';

let appState = null;
let selectedInboxChatId = null;
let adminPassword = '';

function formatCLP(n) {
  const val = Math.round(Number(n) || 0);
  return '$' + Math.abs(val).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function escapeHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatWhatsAppText(str) {
  const safe = escapeHtml(str);
  return safe
    .replace(/\*([^*]+)\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)_([^_]+)_/g, '$1<em>$2</em>');
}

function formatTime(iso) {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

async function apiFetch(url, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }
  if (adminPassword) {
    headers['x-admin-password'] = adminPassword;
  }

  let res = await fetch(url, { ...options, headers });
  if (res.status === 401) {
    const entered = window.prompt('Ingresa la contraseña de administrador (ADMIN_PASSWORD):');
    if (entered !== null) {
      adminPassword = entered;
      headers['x-admin-password'] = adminPassword;
      res = await fetch(url, { ...options, headers });
    }
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Error HTTP ${res.status}`);
  }
  return data;
}

function switchTab(tabName) {
  document.querySelectorAll('.tab').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tab === tabName);
  });
  document.querySelectorAll('.tab-panel').forEach((panel) => {
    panel.classList.toggle('active', panel.id === `tab-${tabName}`);
  });
}

document.querySelectorAll('.tab').forEach((btn) => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});

document.querySelectorAll('[data-tab-jump]').forEach((btn) => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tabJump));
});

async function loadState() {
  appState = await apiFetch('/api/state');
  renderAll();
}

function renderAll() {
  if (!appState) return;
  const { business, menu, orders, conversations, status } = appState;

  // Header
  document.getElementById('header-business-name').textContent = business.name;
  document.getElementById('header-phone').textContent = business.whatsappNumber;
  document.getElementById('header-address').textContent = business.address;

  const pillEngine = document.getElementById('pill-engine');
  pillEngine.textContent = status.llmConfigured
    ? `IA Generativa (${status.llmModel})`
    : 'Motor Local Inteligente Activo';

  const pillMeta = document.getElementById('pill-meta');
  if (status.metaConfigured) {
    pillMeta.textContent = 'Meta API: Conectado';
    pillMeta.className = 'pill pill-green';
  } else {
    pillMeta.textContent = 'Meta API: Listo para conectar';
    pillMeta.className = 'pill pill-muted';
  }

  // Optional missing config banner
  const missing = [];
  if (!business.hoursConfigured) missing.push('Horario de atención');
  if (!business.transferConfigured) missing.push('Datos de transferencia (si quieres enviarlos automáticamente)');
  const banner = document.getElementById('config-banner');
  if (missing.length > 0) {
    document.getElementById('banner-missing-text').textContent = missing.join(' · ');
    banner.classList.remove('hidden');
  } else {
    banner.classList.add('hidden');
  }

  // Orders badge
  const activeOrders = orders.filter((o) => !['entregado', 'cancelado'].includes(o.status)).length;
  document.getElementById('orders-badge').textContent = String(activeOrders);

  // Meta guide tokens
  const callbackEl = document.getElementById('meta-callback-url');
  if (callbackEl) callbackEl.textContent = `${window.location.origin}/webhook`;
  const verifyEl = document.getElementById('meta-verify-token');
  if (verifyEl) verifyEl.textContent = status.verifyToken || 'antojito_caleno_verify_2026';

  renderSimulator(conversations, menu);
  renderOrders(orders);
  renderInbox(conversations);
  renderBusinessForm(business);
  renderMenuList(menu);
}

function renderSimulator(conversations, menu) {
  const conv = conversations.find((c) => c.chatId === SIM_CHAT_ID);
  const box = document.getElementById('sim-messages');
  box.innerHTML = '';

  if (!conv || conv.messages.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'msg msg-bot';
    empty.innerHTML = formatWhatsAppText(
      `¡Hola! Soy el asistente de *Antojito caleño*.\nEscríbeme abajo como si fueras un cliente por WhatsApp (o usa los botones rápidos) para probar cómo tomo pedidos con los precios actualizados.`
    );
    box.appendChild(empty);
  } else {
    for (const m of conv.messages) {
      const div = document.createElement('div');
      div.className = `msg msg-${m.sender}`;
      div.innerHTML = `${formatWhatsAppText(m.text)}<span class="msg-meta">${
        m.sender === 'human_owner' ? 'Dueño (Manual) · ' : ''
      }${formatTime(m.timestamp)}</span>`;
      box.appendChild(div);
    }
  }
  box.scrollTop = box.scrollHeight;

  // Inspector
  const st = conv?.state || {};
  const stageLabels = {
    browsing: 'Explorando / Armando pedido',
    awaiting_checkout: 'Confirmando datos',
    confirmed: 'Pedido confirmado',
  };
  document.getElementById('insp-stage').textContent = stageLabels[st.stage] || 'Explorando';
  document.getElementById('insp-name').textContent = st.customerName || '—';
  document.getElementById('insp-payment').textContent = st.paymentMethod
    ? `${st.paymentMethod}${st.cashNote ? ` (${st.cashNote})` : ''}`
    : '—';
  document.getElementById('insp-notes').textContent =
    st.notes && st.notes.length > 0 ? st.notes.join(', ') : '—';
  document.getElementById('insp-ai-status').textContent = conv?.aiPaused
    ? 'Pausada (Humano)'
    : 'Activa';

  const menuMap = new Map(menu.map((m) => [m.id, m]));
  const cartEl = document.getElementById('insp-cart');
  const cart = st.cart || [];
  if (cart.length === 0) {
    cartEl.innerHTML = '<p class="muted small">Aún no hay productos agregados.</p>';
    document.getElementById('insp-total').textContent = '$0';
  } else {
    let total = 0;
    cartEl.innerHTML = '';
    for (const entry of cart) {
      const item = menuMap.get(entry.id);
      if (!item) continue;
      const sub = item.price * entry.quantity;
      total += sub;
      const row = document.createElement('div');
      row.className = 'cart-row';
      row.innerHTML = `<span>${entry.quantity}x ${escapeHtml(item.name)}</span><strong>${formatCLP(sub)}</strong>`;
      cartEl.appendChild(row);
    }
    document.getElementById('insp-total').textContent = formatCLP(total);
  }

  const lastOrderEl = document.getElementById('insp-last-order');
  if (st.lastOrderNumber) {
    lastOrderEl.classList.remove('hidden');
    lastOrderEl.innerHTML = `✅ Último pedido generado: <strong>${escapeHtml(st.lastOrderNumber)}</strong> (revisa la pestaña <em>Pedidos e Inbox</em>).`;
  } else {
    lastOrderEl.classList.add('hidden');
  }
}

function renderOrders(orders) {
  const container = document.getElementById('orders-list');
  if (!orders || orders.length === 0) {
    container.innerHTML =
      '<p class="muted small">Aún no hay pedidos confirmados. Haz una prueba en el Simulador WhatsApp para verlos aparecer aquí al instante.</p>';
    return;
  }

  container.innerHTML = '';
  for (const o of orders) {
    const card = document.createElement('div');
    card.className = 'order-card';
    const itemsHtml = o.items
      .map(
        (it) =>
          `<li>${it.quantity}x ${escapeHtml(it.name)} — <strong>${formatCLP(it.subtotal)}</strong></li>`
      )
      .join('');

    card.innerHTML = `
      <div class="order-top">
        <div>
          <strong>${escapeHtml(o.orderNumber)}</strong> · ${escapeHtml(o.customerName)}
          <div class="muted small">${escapeHtml(o.customerPhone)} · ${formatTime(o.createdAt)}</div>
        </div>
        <span class="order-status st-${escapeHtml(o.status)}">${escapeHtml(o.status)}</span>
      </div>
      <ul class="order-items">${itemsHtml}</ul>
      <div class="kv">
        <span>Total: <strong>${formatCLP(o.total)}</strong></span>
        <span>Pago: <strong>${escapeHtml(o.paymentMethod)}${o.cashNote ? ` (${escapeHtml(o.cashNote)})` : ''}</strong></span>
      </div>
      ${o.notes ? `<div class="muted small" style="margin-top:4px;">📝 ${escapeHtml(o.notes)}</div>` : ''}
      <div class="order-actions">
        <button class="btn btn-sm" data-ord-id="${escapeHtml(o.id)}" data-st="preparando">Preparando</button>
        <button class="btn btn-sm" data-ord-id="${escapeHtml(o.id)}" data-st="listo">Listo p/ retiro</button>
        <button class="btn btn-sm" data-ord-id="${escapeHtml(o.id)}" data-st="entregado">Entregado</button>
        <button class="btn btn-sm btn-danger" data-ord-id="${escapeHtml(o.id)}" data-st="cancelado">Cancelar</button>
      </div>
    `;
    container.appendChild(card);
  }

  container.querySelectorAll('[data-ord-id]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await apiFetch(`/api/orders/${encodeURIComponent(btn.dataset.ordId)}`, {
          method: 'PATCH',
          body: JSON.stringify({ status: btn.dataset.st }),
        });
        await loadState();
      } catch (err) {
        alert(err.message);
      }
    });
  });
}

function renderInbox(conversations) {
  const listEl = document.getElementById('inbox-chat-list');
  const headEl = document.getElementById('inbox-thread-head');
  const msgsEl = document.getElementById('inbox-thread-messages');
  const replyForm = document.getElementById('inbox-reply-form');

  listEl.innerHTML = '';
  if (!conversations || conversations.length === 0) {
    listEl.innerHTML = '<p class="muted small" style="padding:10px;">Sin chats aún</p>';
    headEl.innerHTML = '<span class="muted">Selecciona una conversación</span>';
    msgsEl.innerHTML = '';
    replyForm.classList.add('hidden');
    return;
  }

  if (!selectedInboxChatId || !conversations.some((c) => c.chatId === selectedInboxChatId)) {
    selectedInboxChatId = conversations[0].chatId;
  }

  for (const c of conversations) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `chat-item ${c.chatId === selectedInboxChatId ? 'active' : ''}`;
    const label = c.state?.customerName || c.profileName || c.chatId;
    const pausedTag = c.aiPaused ? '⏸️ Manual' : '🤖 IA';
    btn.innerHTML = `<strong>${escapeHtml(label)}</strong><small>${escapeHtml(c.source)} · ${pausedTag}</small>`;
    btn.addEventListener('click', () => {
      selectedInboxChatId = c.chatId;
      renderInbox(appState.conversations);
    });
    listEl.appendChild(btn);
  }

  const active = conversations.find((c) => c.chatId === selectedInboxChatId);
  if (!active) return;

  const isPaused = Boolean(
    active.aiPaused || (active.aiPausedUntil && Date.parse(active.aiPausedUntil) > Date.now())
  );

  headEl.innerHTML = `
    <div>
      <strong>${escapeHtml(active.state?.customerName || active.profileName || active.chatId)}</strong>
      <div class="muted small">${escapeHtml(active.customerPhone || active.chatId)}</div>
    </div>
    <button type="button" id="btn-toggle-ai" class="btn btn-sm ${isPaused ? 'btn-primary' : ''}">
      ${isPaused ? '▶ Reactivar IA' : '⏸️ Pausar IA (Responder manual)'}
    </button>
  `;

  document.getElementById('btn-toggle-ai').addEventListener('click', async () => {
    try {
      await apiFetch(`/api/conversations/${encodeURIComponent(active.chatId)}/toggle-ai`, {
        method: 'POST',
        body: JSON.stringify({ aiPaused: !isPaused }),
      });
      await loadState();
    } catch (err) {
      alert(err.message);
    }
  });

  msgsEl.innerHTML = '';
  for (const m of active.messages || []) {
    const div = document.createElement('div');
    div.className = `msg msg-${m.sender}`;
    div.innerHTML = `${formatWhatsAppText(m.text)}<span class="msg-meta">${escapeHtml(m.sender)} · ${formatTime(m.timestamp)}</span>`;
    msgsEl.appendChild(div);
  }
  msgsEl.scrollTop = msgsEl.scrollHeight;
  replyForm.classList.remove('hidden');
}

function renderBusinessForm(business) {
  // Only populate if fields aren't focused to avoid overwriting active edits
  const activeId = document.activeElement?.id;
  if (activeId !== 'biz-name') document.getElementById('biz-name').value = business.name || '';
  if (activeId !== 'biz-phone') document.getElementById('biz-phone').value = business.whatsappNumber || '';
  if (activeId !== 'biz-address') document.getElementById('biz-address').value = business.address || '';
  if (activeId !== 'biz-hours') document.getElementById('biz-hours').value = business.hoursText || '';
  if (activeId !== 'biz-prep') document.getElementById('biz-prep').value = business.prepTimeMinutes || 20;
  if (activeId !== 'biz-transfer') {
    document.getElementById('biz-transfer').value = business.transferInstructions || '';
  }
  if (activeId !== 'biz-autopause') {
    document.getElementById('biz-autopause').value = business.autoPauseOnHumanMinutes || 30;
  }
}

function renderMenuList(menu) {
  const list = document.getElementById('menu-list');
  list.innerHTML = '';

  for (const item of menu) {
    const row = document.createElement('div');
    row.className = `menu-row ${item.available === false ? 'unavailable' : ''}`;
    row.innerHTML = `
      <div class="menu-row-info">
        <strong>${escapeHtml(item.name)} — ${formatCLP(item.price)}</strong>
        <small>${escapeHtml(item.category)} · ${escapeHtml(item.description || 'Sin descripción')}</small>
      </div>
      <div class="menu-row-actions">
        <button type="button" class="btn btn-sm" data-toggle-id="${escapeHtml(item.id)}">
          ${item.available === false ? 'Activar' : 'Agotar'}
        </button>
        <button type="button" class="btn btn-sm" data-edit-id="${escapeHtml(item.id)}">Editar</button>
        <button type="button" class="btn btn-sm btn-danger" data-del-id="${escapeHtml(item.id)}">✕</button>
      </div>
    `;
    list.appendChild(row);
  }

  list.querySelectorAll('[data-toggle-id]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const item = menu.find((m) => m.id === btn.dataset.toggleId);
      if (!item) return;
      try {
        await apiFetch('/api/menu', {
          method: 'POST',
          body: JSON.stringify({ ...item, available: item.available === false }),
        });
        await loadState();
      } catch (err) {
        alert(err.message);
      }
    });
  });

  list.querySelectorAll('[data-edit-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const item = menu.find((m) => m.id === btn.dataset.editId);
      if (!item) return;
      document.getElementById('menu-edit-id').value = item.id;
      document.getElementById('menu-name').value = item.name;
      document.getElementById('menu-cat').value = item.category;
      document.getElementById('menu-price').value = item.price;
      document.getElementById('menu-desc').value = item.description || '';
      document.getElementById('menu-aliases').value = (item.aliases || []).join(', ');
      document.getElementById('menu-submit-btn').textContent = 'Guardar cambios';
      document.getElementById('menu-cancel-edit').classList.remove('hidden');
    });
  });

  list.querySelectorAll('[data-del-id]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      if (!window.confirm('¿Eliminar este producto del menú?')) return;
      try {
        await apiFetch(`/api/menu/${encodeURIComponent(btn.dataset.delId)}`, { method: 'DELETE' });
        await loadState();
      } catch (err) {
        alert(err.message);
      }
    });
  });
}

// Simulator Events
async function sendSimMessage(text) {
  const trimmed = String(text || '').trim();
  if (!trimmed) return;
  const input = document.getElementById('sim-input');
  input.value = '';
  try {
    await apiFetch('/api/simulate', {
      method: 'POST',
      body: JSON.stringify({ chatId: SIM_CHAT_ID, text: trimmed }),
    });
    await loadState();
  } catch (err) {
    alert(err.message);
  }
}

document.getElementById('sim-form').addEventListener('submit', (e) => {
  e.preventDefault();
  sendSimMessage(document.getElementById('sim-input').value);
});

document.querySelectorAll('.chip[data-prompt]').forEach((chip) => {
  chip.addEventListener('click', () => sendSimMessage(chip.dataset.prompt));
});

document.getElementById('btn-reset-sim').addEventListener('click', async () => {
  await apiFetch('/api/simulate/reset', {
    method: 'POST',
    body: JSON.stringify({ chatId: SIM_CHAT_ID }),
  });
  await loadState();
});

document.getElementById('btn-refresh-orders').addEventListener('click', loadState);

// Manual Reply in Inbox
document.getElementById('inbox-reply-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  if (!selectedInboxChatId) return;
  const input = document.getElementById('inbox-reply-input');
  const text = input.value.trim();
  if (!text) return;
  try {
    await apiFetch(`/api/conversations/${encodeURIComponent(selectedInboxChatId)}/manual-reply`, {
      method: 'POST',
      body: JSON.stringify({ text }),
    });
    input.value = '';
    await loadState();
  } catch (err) {
    alert(err.message);
  }
});

// Business Form Submit
document.getElementById('business-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msgEl = document.getElementById('biz-save-msg');
  msgEl.textContent = '';
  try {
    await apiFetch('/api/business', {
      method: 'PUT',
      body: JSON.stringify({
        name: document.getElementById('biz-name').value.trim(),
        whatsappNumber: document.getElementById('biz-phone').value.trim(),
        address: document.getElementById('biz-address').value.trim(),
        hoursText: document.getElementById('biz-hours').value.trim(),
        prepTimeMinutes: Number(document.getElementById('biz-prep').value) || 20,
        transferInstructions: document.getElementById('biz-transfer').value.trim(),
        autoPauseOnHumanMinutes: Number(document.getElementById('biz-autopause').value) || 30,
      }),
    });
    msgEl.textContent = '✓ Guardado correctamente';
    await loadState();
    setTimeout(() => {
      msgEl.textContent = '';
    }, 3000);
  } catch (err) {
    alert(err.message);
  }
});

// Menu Form Submit & Cancel
function clearMenuForm() {
  document.getElementById('menu-edit-id').value = '';
  document.getElementById('menu-name').value = '';
  document.getElementById('menu-cat').value = '';
  document.getElementById('menu-price').value = '';
  document.getElementById('menu-desc').value = '';
  document.getElementById('menu-aliases').value = '';
  document.getElementById('menu-submit-btn').textContent = '+ Guardar producto';
  document.getElementById('menu-cancel-edit').classList.add('hidden');
}

document.getElementById('menu-cancel-edit').addEventListener('click', clearMenuForm);

document.getElementById('menu-add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await apiFetch('/api/menu', {
      method: 'POST',
      body: JSON.stringify({
        id: document.getElementById('menu-edit-id').value || undefined,
        name: document.getElementById('menu-name').value.trim(),
        category: document.getElementById('menu-cat').value.trim(),
        price: Number(document.getElementById('menu-price').value) || 0,
        description: document.getElementById('menu-desc').value.trim(),
        aliases: document.getElementById('menu-aliases').value.trim(),
      }),
    });
    clearMenuForm();
    await loadState();
  } catch (err) {
    alert(err.message);
  }
});

// Meta Webhook Dry-Run Test
document.getElementById('btn-webhook-test').addEventListener('click', async () => {
  const out = document.getElementById('webhook-test-output');
  const testText = document.getElementById('webhook-test-text').value.trim() || 'Hola, menú';
  const payload = {
    object: 'whatsapp_business_account',
    entry: [
      {
        id: 'WABA_DEMO_ID',
        changes: [
          {
            field: 'messages',
            value: {
              messaging_product: 'whatsapp',
              metadata: {
                display_phone_number: '56930543674',
                phone_number_id: 'DEMO_PHONE_NUMBER_ID',
              },
              contacts: [{ profile: { name: 'Cliente Webhook Prueba' }, wa_id: '56912345678' }],
              messages: [
                {
                  from: '56912345678',
                  id: `wamid.test_${Date.now()}`,
                  timestamp: String(Math.floor(Date.now() / 1000)),
                  text: { body: testText },
                  type: 'text',
                },
              ],
            },
          },
        ],
      },
    ],
  };

  try {
    const res = await apiFetch('/api/webhook-test', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    out.textContent = JSON.stringify({ payloadEnviado: payload, resultadoBot: res }, null, 2);
    await loadState();
  } catch (err) {
    out.textContent = `Error: ${err.message}`;
  }
});

loadState();
