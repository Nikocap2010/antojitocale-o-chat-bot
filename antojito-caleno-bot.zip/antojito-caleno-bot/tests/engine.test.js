const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const http = require('node:http');

const { createApp } = require('../src/server');

function createTempDataDir() {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'antojito-test-'));
  const srcDataDir = path.join(__dirname, '..', 'data');
  for (const file of ['business.json', 'menu.json', 'orders.json', 'conversations.json']) {
    fs.copyFileSync(path.join(srcDataDir, file), path.join(tmpDir, file));
  }
  return tmpDir;
}

async function startTestServer(dataDir) {
  const { app, store } = createApp({ dataDir });
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  const baseUrl = `http://127.0.0.1:${port}`;
  return { server, baseUrl, store };
}

test('Precios actualizados y flujo completo con desambiguación de Salchipapa', async () => {
  const tmpDir = createTempDataDir();
  const { server, baseUrl } = await startTestServer(tmpDir);

  try {
    // 1. Consulta menú
    let res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-1', text: 'Hola, ¿me muestras el menú?' }),
    });
    let data = await res.json();
    assert.equal(data.replied, true);
    assert.match(data.reply, /\$2\.200/); // Completo actualizado
    assert.match(data.reply, /\$1\.300/); // Empanadas actualizadas
    assert.match(data.reply, /\$12\.000/); // Salchipapa Especial Grande
    assert.match(data.reply, /Valdivia 1120, Tierras Blancas, Coquimbo/);

    // 2. Pedido mixto con ítem ambiguo ("salchipapa grande")
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chatId: 'test-1',
        text: 'Quiero 2 completos y 1 salchipapa grande',
      }),
    });
    data = await res.json();
    assert.match(data.reply, /2x Completo/);
    assert.match(data.reply, /Salchipapa Grande Tradicional/);
    assert.match(data.reply, /Salchipapa Especial Grande/);
    assert.equal(data.conversation.state.cart.length, 1);

    // 3. Cliente aclara que quiere la especial
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-1', text: 'la especial' }),
    });
    data = await res.json();
    assert.match(data.reply, /2x Completo — \$4\.400/);
    assert.match(data.reply, /1x Salchipapa Especial Grande — \$12\.000/);
    assert.match(data.reply, /\$16\.400/);

    // 4. Cliente entrega nombre y medio de pago -> confirma automáticamente
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-1', text: 'Soy Camila, pago por transferencia' }),
    });
    data = await res.json();
    assert.ok(data.order, 'Debe crear el pedido confirmado');
    assert.equal(data.order.orderNumber, 'AC-0001');
    assert.equal(data.order.customerName, 'Camila');
    assert.equal(data.order.paymentMethod, 'transferencia');
    assert.equal(data.order.total, 16400);
    assert.match(data.reply, /AC-0001/);
    assert.match(data.reply, /Valdivia 1120, Tierras Blancas, Coquimbo/);
    assert.match(data.reply, /enviamos los datos para transferir/i);
  } finally {
    server.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('FAQs de retiro, sin delivery y horario no inventado', async () => {
  const tmpDir = createTempDataDir();
  const { server, baseUrl } = await startTestServer(tmpDir);

  try {
    let res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-faq', text: '¿Hacen delivery?' }),
    });
    let data = await res.json();
    assert.match(data.reply, /solo con retiro en el local/i);
    assert.match(data.reply, /Valdivia 1120, Tierras Blancas, Coquimbo/);

    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-faq', text: '¿A qué hora cierran hoy?' }),
    });
    data = await res.json();
    assert.match(data.reply, /pendiente de confirmar/i);
  } finally {
    server.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('Meta Webhook GET verification, HMAC signature y Coexistence owner echo pause', async () => {
  const tmpDir = createTempDataDir();
  const prevVerify = process.env.META_VERIFY_TOKEN;
  const prevSecret = process.env.META_APP_SECRET;
  process.env.META_VERIFY_TOKEN = 'secret_verify_token';
  process.env.META_APP_SECRET = 'super_app_secret';

  const { server, baseUrl, store } = await startTestServer(tmpDir);

  try {
    // 1. GET /webhook valid & invalid
    const validVerify = await fetch(
      `${baseUrl}/webhook?hub.mode=subscribe&hub.verify_token=secret_verify_token&hub.challenge=123456`
    );
    assert.equal(validVerify.status, 200);
    assert.equal(await validVerify.text(), '123456');

    const badVerify = await fetch(
      `${baseUrl}/webhook?hub.mode=subscribe&hub.verify_token=wrong&hub.challenge=123456`
    );
    assert.equal(badVerify.status, 403);

    // 2. POST /webhook rejects bad signature
    const echoPayload = {
      object: 'whatsapp_business_account',
      entry: [
        {
          id: 'WABA1',
          changes: [
            {
              field: 'smb_message_echoes',
              value: {
                messaging_product: 'whatsapp',
                metadata: { phone_number_id: 'PNID1' },
                smb_message_echoes: [
                  {
                    id: 'wamid.echo1',
                    to: '56999998888',
                    timestamp: '1760000000',
                    type: 'text',
                    text: { body: 'Hola, te atiendo yo directo!' },
                  },
                ],
              },
            },
          ],
        },
      ],
    };
    const rawBody = JSON.stringify(echoPayload);

    const badPost = await fetch(`${baseUrl}/webhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-hub-signature-256': 'sha256=deadbeef' },
      body: rawBody,
    });
    assert.equal(badPost.status, 401);

    // 3. POST /webhook valid signature pauses AI for that chat on Coexistence echo
    const sig =
      'sha256=' + crypto.createHmac('sha256', 'super_app_secret').update(rawBody).digest('hex');
    const goodPost = await fetch(`${baseUrl}/webhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-hub-signature-256': sig },
      body: rawBody,
    });
    assert.equal(goodPost.status, 200);

    // Wait briefly for async webhook handler
    await new Promise((r) => setTimeout(r, 120));
    const conv = store.getConversation('56999998888');
    assert.ok(conv.aiPausedUntil, 'Coexistence echo debe pausar la IA temporalmente');
    assert.equal(conv.messages[0].sender, 'human_owner');
  } finally {
    server.close();
    if (prevVerify === undefined) delete process.env.META_VERIFY_TOKEN;
    else process.env.META_VERIFY_TOKEN = prevVerify;
    if (prevSecret === undefined) delete process.env.META_APP_SECRET;
    else process.env.META_APP_SECRET = prevSecret;
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('Consulta de precio individual, Fritanga, notas y pago en efectivo con vuelto', async () => {
  const tmpDir = createTempDataDir();
  const { server, baseUrl } = await startTestServer(tmpDir);

  try {
    // 1. Precio individual sin agregar al carrito
    let res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-fritanga', text: '¿Cuánto vale el completo?' }),
    });
    let data = await res.json();
    assert.match(data.reply, /\$2\.200/);
    assert.equal(data.conversation.state.cart.length, 0);

    // 2. Pedido Día Fritanga + notas
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chatId: 'test-fritanga',
        text: 'Dame una arepa con chicharron, 2 aborrajados y 3 empanadas de queso sin aji',
      }),
    });
    data = await res.json();
    // 4800 + 2*2500 (5000) + 3*1300 (3900) = 13700
    assert.match(data.reply, /\$13\.700/);
    assert.match(data.reply, /sin aji/i);

    // 3. Efectivo con vuelto
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-fritanga', text: 'Soy Diego, pago con 20 mil' }),
    });
    data = await res.json();
    assert.ok(data.order);
    assert.equal(data.order.total, 13700);
    assert.equal(data.order.paymentMethod, 'efectivo');
    assert.equal(data.order.cashNote, 'Paga con $20.000');
  } finally {
    server.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});

test('Bebidas: Coca-Cola, Limón Soda, Kem 1L, Pony Malta y Postobón 400ml / 1,5L', async () => {
  const tmpDir = createTempDataDir();
  const { server, baseUrl } = await startTestServer(tmpDir);

  try {
    // 1. Consulta de bebidas
    let res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-bebidas', text: '¿Qué bebidas tienen?' }),
    });
    let data = await res.json();
    assert.match(data.reply, /Coca-Cola 1 Litro.*\$1\.500/);
    assert.match(data.reply, /Limón Soda 1 Litro.*\$1\.500/);
    assert.match(data.reply, /Kem 1 Litro.*\$1\.500/);
    assert.match(data.reply, /Pony Malta.*\$1\.800/);
    assert.match(data.reply, /Postobón 400 ml.*\$1\.500/);
    assert.match(data.reply, /Postobón 1,5 Litros.*\$2\.800/);

    // 2. Pedido directo con typo "pony malata" + 3 bebidas 1L
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chatId: 'test-bebidas',
        text: 'Quiero 1 cocacola, 1 limon soda, 1 kem y 1 pony malata',
      }),
    });
    data = await res.json();
    // 1500 + 1500 + 1500 + 1800 = 6300
    assert.match(data.reply, /\$6\.300/);

    // 3. Desambiguación de Postobón ("la de 1,5 litros" no debe confundirse con opción 1)
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-bebidas', text: 'Agrega una postobon' }),
    });
    data = await res.json();
    assert.match(data.reply, /Postobón 400 ml/);
    assert.match(data.reply, /Postobón 1,5 Litros/);

    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-bebidas', text: 'la de 1,5 litros' }),
    });
    data = await res.json();
    // 6300 + 2800 = 9100
    assert.match(data.reply, /1x Postobón 1,5 Litros — \$2\.800/);
    assert.match(data.reply, /\$9\.100/);

    // 4. Pedido directo con 2 postobon 400ml
    res = await fetch(`${baseUrl}/api/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: 'test-bebidas', text: 'y 2 postobon 400ml' }),
    });
    data = await res.json();
    // 9100 + 3000 = 12100
    assert.match(data.reply, /2x Postobón 400 ml — \$3\.000/);
    assert.match(data.reply, /\$12\.100/);
  } finally {
    server.close();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
});


