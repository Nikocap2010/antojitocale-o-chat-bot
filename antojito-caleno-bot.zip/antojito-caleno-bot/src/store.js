const fs = require('node:fs');
const path = require('node:path');

const DEFAULT_DATA_DIR = path.join(__dirname, '..', 'data');

function formatCLP(amount) {
  const n = Math.round(Number(amount) || 0);
  const sign = n < 0 ? '-' : '';
  const digits = Math.abs(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${sign}$${digits}`;
}

function readJsonSafe(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf8');
    if (!raw.trim()) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err.message);
    return fallback;
  }
}

function writeJsonAtomic(filePath, data) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const tmpPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2) + '\n', 'utf8');
  fs.renameSync(tmpPath, filePath);
}

function createStore(dataDir = DEFAULT_DATA_DIR) {
  const files = {
    business: path.join(dataDir, 'business.json'),
    menu: path.join(dataDir, 'menu.json'),
    orders: path.join(dataDir, 'orders.json'),
    conversations: path.join(dataDir, 'conversations.json'),
  };

  function getBusiness() {
    return readJsonSafe(files.business, {
      name: 'Antojito caleño',
      whatsappNumber: '+56 9 3054 3674',
      address: 'Valdivia 1120, Tierras Blancas, Coquimbo',
      fulfillmentMode: 'pickup_only',
      fulfillmentLabel: 'Solo retiro en local',
      currency: 'CLP',
      hoursConfigured: false,
      hoursText: '',
      prepTimeMinutes: 20,
      paymentMethods: ['efectivo', 'transferencia'],
      transferConfigured: false,
      transferInstructions: '',
      autoPauseOnHumanMinutes: 30,
      extraNotes: '',
    });
  }

  function saveBusiness(patch) {
    const current = getBusiness();
    const updated = {
      ...current,
      ...patch,
      fulfillmentMode: 'pickup_only',
    };
    if (typeof updated.hoursText === 'string' && updated.hoursText.trim().length > 0) {
      updated.hoursConfigured = true;
    } else if (patch.hoursText === '') {
      updated.hoursConfigured = false;
    }
    if (
      typeof updated.transferInstructions === 'string' &&
      updated.transferInstructions.trim().length > 0
    ) {
      updated.transferConfigured = true;
    } else if (patch.transferInstructions === '') {
      updated.transferConfigured = false;
    }
    writeJsonAtomic(files.business, updated);
    return updated;
  }

  function getMenu() {
    return readJsonSafe(files.menu, []);
  }

  function saveMenu(items) {
    const sanitized = (Array.isArray(items) ? items : []).map((item) => ({
      id: String(item.id || '').trim() || `item-${Date.now()}`,
      name: String(item.name || '').trim(),
      category: String(item.category || 'General').trim(),
      price: Math.max(0, Math.round(Number(item.price) || 0)),
      description: String(item.description || '').trim(),
      aliases: Array.isArray(item.aliases)
        ? item.aliases.map((a) => String(a).trim()).filter(Boolean)
        : [],
      available: item.available !== false,
    }));
    writeJsonAtomic(files.menu, sanitized);
    return sanitized;
  }

  function upsertMenuItem(item) {
    const menu = getMenu();
    const id =
      String(item.id || '').trim() ||
      String(item.name || 'item')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '') +
        '-' +
        Math.floor(Math.random() * 1000);

    const normalizedItem = {
      id,
      name: String(item.name || '').trim(),
      category: String(item.category || 'General').trim(),
      price: Math.max(0, Math.round(Number(item.price) || 0)),
      description: String(item.description || '').trim(),
      aliases: Array.isArray(item.aliases)
        ? item.aliases.map((a) => String(a).trim()).filter(Boolean)
        : typeof item.aliases === 'string'
          ? item.aliases
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean)
          : [],
      available: item.available !== false,
    };

    const idx = menu.findIndex((m) => m.id === id);
    if (idx >= 0) {
      menu[idx] = { ...menu[idx], ...normalizedItem };
    } else {
      menu.push(normalizedItem);
    }
    return saveMenu(menu);
  }

  function deleteMenuItem(id) {
    const menu = getMenu().filter((m) => m.id !== id);
    return saveMenu(menu);
  }

  function getOrders() {
    return readJsonSafe(files.orders, []);
  }

  function createOrder({ chatId, customerName, customerPhone, items, total, paymentMethod, cashNote, notes, source }) {
    const orders = getOrders();
    const nextNum = orders.length + 1;
    const orderNumber = `AC-${String(nextNum).padStart(4, '0')}`;
    const order = {
      id: `ord_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      orderNumber,
      chatId,
      customerName: customerName || 'Cliente',
      customerPhone: customerPhone || chatId,
      items: items.map((it) => ({
        id: it.id,
        name: it.name,
        quantity: it.quantity,
        unitPrice: it.unitPrice,
        subtotal: it.unitPrice * it.quantity,
      })),
      total,
      paymentMethod,
      cashNote: cashNote || '',
      notes: notes || '',
      fulfillment: 'Retiro en local',
      pickupAddress: getBusiness().address,
      status: 'nuevo',
      source: source || 'whatsapp',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    orders.unshift(order);
    writeJsonAtomic(files.orders, orders);
    return order;
  }

  function updateOrderStatus(orderId, status) {
    const allowed = ['nuevo', 'preparando', 'listo', 'entregado', 'cancelado'];
    if (!allowed.includes(status)) {
      throw new Error(`Estado inválido: ${status}`);
    }
    const orders = getOrders();
    const idx = orders.findIndex((o) => o.id === orderId || o.orderNumber === orderId);
    if (idx === -1) return null;
    orders[idx] = {
      ...orders[idx],
      status,
      updatedAt: new Date().toISOString(),
    };
    writeJsonAtomic(files.orders, orders);
    return orders[idx];
  }

  function getConversations() {
    return readJsonSafe(files.conversations, {});
  }

  function createEmptyConversation(chatId, meta = {}) {
    return {
      chatId,
      customerPhone: meta.customerPhone || chatId,
      profileName: meta.profileName || '',
      source: meta.source || 'simulator',
      aiPaused: false,
      aiPausedUntil: null,
      state: {
        cart: [],
        customerName: meta.customerName || '',
        paymentMethod: '',
        cashNote: '',
        notes: [],
        pendingChoice: null,
        stage: 'browsing', // browsing | awaiting_checkout | confirmed
        lastOrderNumber: null,
      },
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  }

  function getConversation(chatId, meta = {}) {
    const all = getConversations();
    if (!all[chatId]) {
      all[chatId] = createEmptyConversation(chatId, meta);
      writeJsonAtomic(files.conversations, all);
    }
    return all[chatId];
  }

  function saveConversation(chatId, conv) {
    const all = getConversations();
    conv.updatedAt = new Date().toISOString();
    // Keep last 120 messages per chat to keep storage light
    if (Array.isArray(conv.messages) && conv.messages.length > 120) {
      conv.messages = conv.messages.slice(-120);
    }
    all[chatId] = conv;
    writeJsonAtomic(files.conversations, all);
    return conv;
  }

  function resetConversation(chatId, meta = {}) {
    const all = getConversations();
    all[chatId] = createEmptyConversation(chatId, meta);
    writeJsonAtomic(files.conversations, all);
    return all[chatId];
  }

  return {
    formatCLP,
    getBusiness,
    saveBusiness,
    getMenu,
    saveMenu,
    upsertMenuItem,
    deleteMenuItem,
    getOrders,
    createOrder,
    updateOrderStatus,
    getConversations,
    getConversation,
    saveConversation,
    resetConversation,
  };
}

module.exports = {
  createStore,
  formatCLP,
};
