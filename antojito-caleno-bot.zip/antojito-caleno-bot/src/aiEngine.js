const { formatCLP } = require('./store');
const {
  normalizeText,
  buildMenuText,
  calculateCartTotals,
  formatCartSummary,
  resolvePendingChoice,
  parseOrderActions,
  extractCheckoutFields,
  detectIntent,
} = require('./parser');
const { isLlmConfigured, runLlmTurn } = require('./llmClient');

function findMentionedItems(text, menu) {
  const norm = normalizeText(text);
  const available = menu.filter((m) => m.available !== false);
  return available.filter((item) => {
    const terms = [normalizeText(item.name), ...(item.aliases || []).map(normalizeText)];
    return terms.some((t) => t && norm.includes(t));
  });
}

function formatPendingChoicePrompt(pendingChoice, menu) {
  const opts = pendingChoice.options
    .map((id) => menu.find((m) => m.id === id && m.available !== false))
    .filter(Boolean);

  const qtyText = pendingChoice.quantity > 1 ? `${pendingChoice.quantity}x ` : '';
  const lines = [`Sobre *${qtyText}${pendingChoice.family}*, ¿cuál opción prefieres?`];
  opts.forEach((opt, i) => {
    const extra = opt.id.includes('especial')
      ? ' _(lechuga, papa salchicha, papa hilo, pollo desmechado, costilla BBQ, queso y salsa de la casa)_'
      : '';
    lines.push(`${i + 1}️⃣ *${opt.name}* — ${formatCLP(opt.price)}${extra}`);
  });
  lines.push('Respóndeme con el número o el nombre de la opción.');
  return lines.join('\n');
}

function buildConfirmationMessage(order, business) {
  const itemLines = order.items.map(
    (it) => `• ${it.quantity}x ${it.name} — ${formatCLP(it.subtotal)}`
  );

  const paymentLabel =
    order.paymentMethod === 'transferencia'
      ? 'Transferencia'
      : `Efectivo${order.cashNote ? ` (${order.cashNote})` : ''}`;

  const transferLine =
    order.paymentMethod === 'transferencia'
      ? business.transferConfigured
        ? `\n💳 *Datos de transferencia:*\n${business.transferInstructions}`
        : '\n💳 *Transferencia:* Apenas revisemos tu pedido por aquí te enviamos los datos para transferir (o puedes transferir al retirar).'
      : '';

  const notesLine = order.notes ? `\n📝 *Notas:* ${order.notes}` : '';

  return [
    `✅ *¡Pedido confirmado! (${order.orderNumber})*`,
    '',
    ...itemLines,
    `*Total:* ${formatCLP(order.total)}`,
    '',
    `👤 *A nombre de:* ${order.customerName}`,
    `💵 *Pago:* ${paymentLabel}${notesLine}${transferLine}`,
    `📍 *Retiro en local:* ${business.address}`,
    `⏱️ *Tiempo estimado:* ~${business.prepTimeMinutes || 20} min`,
    '',
    `¡Gracias por preferir *${business.name}*! Te avisamos por aquí cuando esté listo.`,
  ].join('\n');
}

function mergeCartItem(cart, itemId, qty) {
  const next = [...(cart || [])];
  const idx = next.findIndex((c) => c.id === itemId);
  if (idx >= 0) {
    next[idx] = { ...next[idx], quantity: next[idx].quantity + qty };
  } else {
    next.push({ id: itemId, quantity: qty });
  }
  return next;
}

function removeCartItem(cart, itemId, qty) {
  const next = [];
  for (const entry of cart || []) {
    if (entry.id !== itemId) {
      next.push(entry);
      continue;
    }
    const remaining = entry.quantity - qty;
    if (remaining > 0) {
      next.push({ ...entry, quantity: remaining });
    }
  }
  return next;
}

function finalizeOrder({ store, conv, business, menu, source }) {
  const { items, total } = calculateCartTotals(conv.state.cart, menu);
  if (items.length === 0) return null;

  const order = store.createOrder({
    chatId: conv.chatId,
    customerName: conv.state.customerName || conv.profileName || 'Cliente',
    customerPhone: conv.customerPhone || conv.chatId,
    items,
    total,
    paymentMethod: conv.state.paymentMethod || 'efectivo',
    cashNote: conv.state.cashNote || '',
    notes: (conv.state.notes || []).join(', '),
    source: source || conv.source || 'whatsapp',
  });

  const confirmationText = buildConfirmationMessage(order, business);

  conv.state.cart = [];
  conv.state.pendingChoice = null;
  conv.state.notes = [];
  conv.state.paymentMethod = '';
  conv.state.cashNote = '';
  conv.state.stage = 'confirmed';
  conv.state.lastOrderNumber = order.orderNumber;

  return { order, reply: confirmationText };
}

function buildMissingCheckoutPrompt(conv, business, menu) {
  const summary = formatCartSummary(conv.state.cart, menu);
  const missingName = !conv.state.customerName;
  const missingPayment = !conv.state.paymentMethod;

  if (missingName && missingPayment) {
    conv.state.stage = 'awaiting_checkout';
    return `${summary}\n\n¿Deseas agregar algo más? Para confirmar tu retiro en *${business.address}*, indícame:\n• *Tu nombre*\n• *Medio de pago* (efectivo o transferencia)`;
  }
  if (missingName) {
    conv.state.stage = 'awaiting_checkout';
    return `${summary}\n\nPago seleccionado: *${conv.state.paymentMethod === 'transferencia' ? 'Transferencia' : 'Efectivo'}*.\n¿A nombre de quién dejamos el pedido para retiro en *${business.address}*?`;
  }
  if (missingPayment) {
    conv.state.stage = 'awaiting_checkout';
    return `${summary}\n\nA nombre de *${conv.state.customerName}*.\n¿Pagas con *efectivo* o *transferencia*?`;
  }
  conv.state.stage = 'awaiting_checkout';
  return `${summary}\n\n👤 *A nombre de:* ${conv.state.customerName}\n💵 *Pago:* ${conv.state.paymentMethod === 'transferencia' ? 'Transferencia' : 'Efectivo'}\n📍 *Retiro:* ${business.address}\n\n¿Confirmamos tu pedido?`;
}

function runLocalTurn({ store, conv, userText, business, menu, source }) {
  const intent = detectIntent(userText);

  if (intent.asksHuman) {
    conv.aiPaused = true;
    return {
      reply: `Entendido 🙌 Pausé el asistente automático. Alguien del equipo de *${business.name}* te responderá por este mismo chat en un momento.`,
      order: null,
      engine: 'local',
    };
  }

  let resolvedChoiceItem = null;
  if (conv.state.pendingChoice) {
    const resolved = resolvePendingChoice(userText, conv.state.pendingChoice, menu);
    if (resolved) {
      conv.state.cart = mergeCartItem(conv.state.cart, resolved.item.id, resolved.quantity);
      conv.state.pendingChoice = null;
      resolvedChoiceItem = resolved;
    }
  }

  const parsed = resolvedChoiceItem
    ? { action: 'add', additions: [], removals: [], ambiguous: [], notes: [] }
    : parseOrderActions(userText, menu);

  if (parsed.action === 'clear') {
    conv.state.cart = [];
    conv.state.notes = [];
    conv.state.pendingChoice = null;
    conv.state.paymentMethod = '';
    conv.state.cashNote = '';
    conv.state.stage = 'browsing';
    return {
      reply: 'Listo, vacié tu pedido actual. Si quieres comenzar de nuevo, dime qué deseas pedir o escribe *menú* 😊',
      order: null,
      engine: 'local',
    };
  }

  for (const add of parsed.additions) {
    conv.state.cart = mergeCartItem(conv.state.cart, add.item.id, add.quantity);
  }
  for (const rem of parsed.removals) {
    conv.state.cart = removeCartItem(conv.state.cart, rem.item.id, rem.quantity);
  }
  if (parsed.notes.length > 0) {
    const mergedNotes = new Set([...(conv.state.notes || []), ...parsed.notes]);
    conv.state.notes = Array.from(mergedNotes);
  }

  const hasCartItems = calculateCartTotals(conv.state.cart, menu).items.length > 0;
  const noProductChanges =
    !resolvedChoiceItem &&
    parsed.additions.length === 0 &&
    parsed.removals.length === 0 &&
    parsed.ambiguous.length === 0;

  const expectingCheckoutName =
    hasCartItems &&
    !conv.state.customerName &&
    conv.state.stage === 'awaiting_checkout' &&
    noProductChanges &&
    !intent.asksMenu &&
    !intent.asksDrinks &&
    !intent.asksLocation &&
    !intent.asksDelivery &&
    !intent.asksHours;

  const checkout = extractCheckoutFields(userText, expectingCheckoutName);

  if (checkout.customerName) {
    conv.state.customerName = checkout.customerName;
  }
  // Only apply payment method if cart has items OR explicitly stated "pago con/en ..."
  const explicitPaymentIntent =
    /\b(pago|pagar|pagare|pagaré)\b/.test(normalizeText(userText)) ||
    (hasCartItems && !intent.asksPayment);
  if (checkout.paymentMethod && (hasCartItems || explicitPaymentIntent)) {
    conv.state.paymentMethod = checkout.paymentMethod;
  }
  if (checkout.cashNote) {
    conv.state.cashNote = checkout.cashNote;
  }

  // Case 1: Ambiguity detected
  if (parsed.ambiguous.length > 0) {
    conv.state.pendingChoice = parsed.ambiguous[0];
    const parts = [];
    if (parsed.additions.length > 0) {
      parts.push(
        `Agregué: ${parsed.additions.map((a) => `*${a.quantity}x ${a.item.name}*`).join(', ')}.`
      );
    }
    parts.push(formatPendingChoicePrompt(parsed.ambiguous[0], menu));
    return { reply: parts.join('\n\n'), order: null, engine: 'local' };
  }

  // Case 2: Items were added, removed, or pending choice resolved
  if (resolvedChoiceItem || parsed.additions.length > 0 || parsed.removals.length > 0) {
    const validTotals = calculateCartTotals(conv.state.cart, menu);
    if (validTotals.items.length === 0) {
      conv.state.stage = 'browsing';
      return {
        reply: 'Tu pedido quedó vacío. ¿Te muestro el *menú* o quieres pedir algo más?',
        order: null,
        engine: 'local',
      };
    }

    if (checkout.wantsToConfirm && conv.state.customerName && conv.state.paymentMethod) {
      const finalized = finalizeOrder({ store, conv, business, menu, source });
      return { reply: finalized.reply, order: finalized.order, engine: 'local' };
    }

    const prefix = intent.isGreeting ? `¡Hola! Bienvenido a *${business.name}* 😊\n\n` : '';
    const noteText =
      parsed.notes.length > 0 ? `\n📝 Anotado: _${parsed.notes.join(', ')}_` : '';
    const prompt = buildMissingCheckoutPrompt(conv, business, menu);
    return {
      reply: `${prefix}Anotado 👍${noteText}\n\n${prompt}`,
      order: null,
      engine: 'local',
    };
  }

  // Case 3: Pure FAQ / Business info questions
  const faqParts = [];
  if (intent.asksDelivery) {
    faqParts.push(
      `Por ahora trabajamos *solo con retiro en el local* (no realizamos delivery).\n📍 Dirección: *${business.address}*`
    );
  } else if (intent.asksLocation) {
    faqParts.push(`📍 Retiras tu pedido en *${business.address}* (solo retiro en local).`);
  }

  if (intent.asksHours) {
    faqParts.push(
      business.hoursConfigured
        ? `🕒 *Horario de atención:* ${business.hoursText}`
        : `🕒 El horario de atención está pendiente de confirmar aquí en el sistema; si quieres, dime qué deseas pedir o escribe *humano* para consultarnos directo.`
    );
  }

  if (intent.asksPayment && (!hasCartItems || /\b(aceptan|tarjeta|webpay|debito|credito|medios|formas|como se paga|como pago)\b/.test(normalizeText(userText)))) {
    faqParts.push(
      `💳 Aceptamos *efectivo* y *transferencia* (por ahora no manejamos tarjeta/Webpay).`
    );
  }

  if (intent.asksIngredients) {
    const mentioned = findMentionedItems(userText, menu);
    if (mentioned.length > 0) {
      for (const m of mentioned) {
        faqParts.push(`🍽️ *${m.name}* (${formatCLP(m.price)}): ${m.description}`);
      }
    } else if (normalizeText(userText).includes('salchipapa')) {
      const salchis = menu.filter((m) => m.id.startsWith('salchipapa-') && m.available !== false);
      faqParts.push(
        salchis.map((s) => `• *${s.name}* (${formatCLP(s.price)}): ${s.description}`).join('\n')
      );
    }
  }

  if (intent.asksDrinks && !intent.asksMenu) {
    const drinks = menu.filter(
      (m) => m.available !== false && normalizeText(m.category).includes('bebida')
    );
    if (drinks.length > 0) {
      faqParts.push(
        [
          '🥤 *Bebidas disponibles:*',
          ...drinks.map((d) => `• *${d.name}*: ${formatCLP(d.price)}`),
        ].join('\n')
      );
    }
  }

  if (intent.asksMenu) {
    const mentioned = findMentionedItems(userText, menu);
    const askingSinglePrice = /\b(cuanto vale|cuanto cuesta|cuanto sale|a cuanto)\b/.test(
      normalizeText(userText)
    );
    if (askingSinglePrice && mentioned.length > 0 && mentioned.length <= 3) {
      for (const m of mentioned) {
        faqParts.push(`• *${m.name}*: *${formatCLP(m.price)}* — ${m.description}`);
      }
    } else {
      faqParts.push(buildMenuText(menu, business));
    }
  }

  if (faqParts.length > 0) {
    return { reply: faqParts.join('\n\n'), order: null, engine: 'local' };
  }

  // Case 4: Cart status request
  if (intent.asksOrderStatus) {
    if (!hasCartItems) {
      return {
        reply: `Aún no tienes productos en tu pedido. Escribe *menú* para ver nuestra carta o dime qué deseas pedir 😊`,
        order: null,
        engine: 'local',
      };
    }
    return {
      reply: buildMissingCheckoutPrompt(conv, business, menu),
      order: null,
      engine: 'local',
    };
  }

  // Case 5: Checkout progress / Confirmation
  if (hasCartItems) {
    const readyToFinalize =
      conv.state.customerName &&
      conv.state.paymentMethod &&
      (checkout.wantsToConfirm || conv.state.stage === 'awaiting_checkout');

    if (readyToFinalize) {
      const finalized = finalizeOrder({ store, conv, business, menu, source });
      return { reply: finalized.reply, order: finalized.order, engine: 'local' };
    }

    if (checkout.customerName || checkout.paymentMethod || checkout.wantsToConfirm) {
      return {
        reply: buildMissingCheckoutPrompt(conv, business, menu),
        order: null,
        engine: 'local',
      };
    }
  }

  // Case 6: Greeting with empty cart (or after previous order)
  if (intent.isGreeting) {
    return {
      reply: `¡Hola! Bienvenido a *${business.name}* 😊\n📍 Retiro en local: *${business.address}*\n\n${buildMenuText(menu, business)}`,
      order: null,
      engine: 'local',
    };
  }

  // Case 7: Polite fallback
  return {
    reply: `¡Gracias por escribir a *${business.name}*! 😊\nPuedes pedirme el *menú*, preguntarme por la dirección o decirme directo qué quieres pedir (por ejemplo: _"2 completos y 1 papas grande"_).\n\nSi necesitas atención directa de una persona, escribe *humano*.`,
    order: null,
    engine: 'local',
  };
}

/**
 * Process an incoming customer message and persist conversation state
 */
async function handleIncomingMessage({
  store,
  chatId,
  text,
  customerPhone,
  profileName,
  source = 'whatsapp',
  externalMessageId = null,
}) {
  const business = store.getBusiness();
  const menu = store.getMenu();
  const conv = store.getConversation(chatId, {
    customerPhone: customerPhone || chatId,
    profileName: profileName || '',
    source,
  });

  if (profileName && !conv.profileName) {
    conv.profileName = profileName;
  }
  conv.source = source;

  conv.messages.push({
    id: externalMessageId || `msg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    sender: 'customer',
    text: String(text || '').trim(),
    timestamp: new Date().toISOString(),
  });

  // Check if AI is paused (manual human takeover or Coexistence owner reply)
  const pausedUntilMs = conv.aiPausedUntil ? Date.parse(conv.aiPausedUntil) : 0;
  if (conv.aiPaused || (pausedUntilMs && pausedUntilMs > Date.now())) {
    store.saveConversation(chatId, conv);
    return {
      replied: false,
      reason: 'ai_paused',
      reply: null,
      order: null,
      conversation: conv,
    };
  } else if (pausedUntilMs && pausedUntilMs <= Date.now()) {
    conv.aiPausedUntil = null;
  }

  let result = null;

  // Optional LLM mode (still uses deterministic server math & validation!)
  if (isLlmConfigured()) {
    const llmOut = await runLlmTurn({ userText: text, business, menu, conv });
    if (llmOut && typeof llmOut.reply === 'string') {
      if (llmOut.pauseForHuman) {
        conv.aiPaused = true;
      }
      if (llmOut.clearCart) {
        conv.state.cart = [];
        conv.state.notes = [];
      }
      if (Array.isArray(llmOut.addItems)) {
        for (const a of llmOut.addItems) {
          const found = menu.find((m) => m.id === a.id && m.available !== false);
          if (found) {
            conv.state.cart = mergeCartItem(
              conv.state.cart,
              found.id,
              Math.max(1, Math.round(Number(a.quantity) || 1))
            );
          }
        }
      }
      if (Array.isArray(llmOut.removeItems)) {
        for (const r of llmOut.removeItems) {
          conv.state.cart = removeCartItem(
            conv.state.cart,
            r.id,
            Math.max(1, Math.round(Number(r.quantity) || 1))
          );
        }
      }
      if (llmOut.customerName) conv.state.customerName = String(llmOut.customerName).trim();
      if (llmOut.paymentMethod === 'efectivo' || llmOut.paymentMethod === 'transferencia') {
        conv.state.paymentMethod = llmOut.paymentMethod;
      }
      if (llmOut.cashNote) conv.state.cashNote = String(llmOut.cashNote).trim();
      if (Array.isArray(llmOut.notes) && llmOut.notes.length > 0) {
        conv.state.notes = Array.from(new Set([...(conv.state.notes || []), ...llmOut.notes]));
      }

      const valid = calculateCartTotals(conv.state.cart, menu);
      if (
        llmOut.confirmOrder &&
        valid.items.length > 0 &&
        conv.state.customerName &&
        conv.state.paymentMethod
      ) {
        const finalized = finalizeOrder({ store, conv, business, menu, source });
        result = { reply: finalized.reply, order: finalized.order, engine: 'llm' };
      } else {
        result = { reply: llmOut.reply.trim(), order: null, engine: 'llm' };
      }
    }
  }

  if (!result) {
    result = runLocalTurn({ store, conv, userText: text, business, menu, source });
  }

  conv.messages.push({
    id: `bot_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    sender: 'bot',
    text: result.reply,
    engine: result.engine,
    orderNumber: result.order ? result.order.orderNumber : null,
    timestamp: new Date().toISOString(),
  });

  store.saveConversation(chatId, conv);

  return {
    replied: true,
    reply: result.reply,
    order: result.order,
    engine: result.engine,
    conversation: conv,
  };
}

module.exports = {
  handleIncomingMessage,
  buildConfirmationMessage,
};
