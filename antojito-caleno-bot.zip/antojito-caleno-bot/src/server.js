require('dotenv').config();
const path = require('node:path');
const express = require('express');
const { createStore } = require('./store');
const { handleIncomingMessage } = require('./aiEngine');
const { isLlmConfigured } = require('./llmClient');
const {
  getMetaConfig,
  verifyMetaSignature,
  extractWebhookEvents,
  sendWhatsAppText,
  markWhatsAppRead,
} = require('./whatsappClient');

function createApp(options = {}) {
  const store = createStore(options.dataDir);
  const app = express();

  app.use(
    express.json({
      limit: '2mb',
      verify: (req, _res, buf) => {
        req.rawBody = buf;
      },
    })
  );

  // Serve frontend UI
  app.use(express.static(path.join(__dirname, '..', 'public')));

  function requireAdmin(req, res, next) {
    const adminPass = (process.env.ADMIN_PASSWORD || '').trim();
    if (!adminPass) return next();
    const provided =
      req.headers['x-admin-password'] ||
      (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (provided === adminPass) return next();
    return res.status(401).json({ error: 'Contraseña de administrador requerida o incorrecta' });
  }

  app.get('/health', (_req, res) => {
    const meta = getMetaConfig();
    res.json({
      ok: true,
      service: 'antojito-caleno-bot',
      metaConfigured: meta.configured,
      llmConfigured: isLlmConfigured(),
      timestamp: new Date().toISOString(),
    });
  });

  // Meta WhatsApp Cloud API Webhook Verification
  app.get('/webhook', (req, res) => {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];
    const { verifyToken } = getMetaConfig();

    if (mode === 'subscribe' && token === verifyToken) {
      return res.status(200).send(String(challenge || ''));
    }
    return res.sendStatus(403);
  });

  // Shared webhook processor (used by /webhook and /api/webhook-test)
  async function processMetaWebhookPayload(payload, { dryRun = false } = {}) {
    const { customerMessages, ownerEchoes } = extractWebhookEvents(payload);
    const business = store.getBusiness();
    const processed = [];

    // Handle Coexistence echoes: when the business replies manually from the phone app
    for (const echo of ownerEchoes) {
      const conv = store.getConversation(echo.to, {
        customerPhone: echo.to,
        source: 'whatsapp',
      });
      conv.messages.push({
        id: echo.messageId || `echo_${Date.now()}`,
        sender: 'human_owner',
        text: echo.text,
        timestamp: new Date().toISOString(),
      });
      const pauseMins = Number(business.autoPauseOnHumanMinutes) || 30;
      conv.aiPausedUntil = new Date(Date.now() + pauseMins * 60 * 1000).toISOString();
      store.saveConversation(echo.to, conv);
      processed.push({ type: 'owner_echo', to: echo.to, pausedMinutes: pauseMins });
    }

    // Handle customer incoming messages
    for (const msg of customerMessages) {
      if (!msg.supported) {
        const conv = store.getConversation(msg.from, {
          customerPhone: msg.from,
          profileName: msg.profileName,
          source: 'whatsapp',
        });
        conv.messages.push({
          id: msg.messageId,
          sender: 'customer',
          text: `[Mensaje ${msg.mediaType} no soportado automáticamente]`,
          timestamp: new Date().toISOString(),
        });
        const mediaReply =
          'Por ahora solo puedo leer mensajes de texto para tomar tu pedido 😊 Por favor escríbeme qué deseas pedir o escribe *menú*.';
        conv.messages.push({
          id: `bot_${Date.now()}`,
          sender: 'bot',
          text: mediaReply,
          timestamp: new Date().toISOString(),
        });
        store.saveConversation(msg.from, conv);

        if (!dryRun) {
          await sendWhatsAppText({
            to: msg.from,
            text: mediaReply,
            phoneNumberId: msg.phoneNumberId,
          }).catch((err) => console.error('WhatsApp send error:', err.message));
        }

        processed.push({
          type: 'unsupported_media',
          from: msg.from,
          mediaType: msg.mediaType,
          reply: mediaReply,
        });
        continue;
      }

      if (!dryRun) {
        markWhatsAppRead({
          messageId: msg.messageId,
          phoneNumberId: msg.phoneNumberId,
        });
      }

      const result = await handleIncomingMessage({
        store,
        chatId: msg.from,
        text: msg.text,
        customerPhone: msg.from,
        profileName: msg.profileName,
        source: dryRun ? 'webhook_test' : 'whatsapp',
        externalMessageId: msg.messageId,
      });

      let delivery = { sent: false, reason: dryRun ? 'dry_run' : 'ai_paused' };
      if (result.replied && result.reply && !dryRun) {
        delivery = await sendWhatsAppText({
          to: msg.from,
          text: result.reply,
          phoneNumberId: msg.phoneNumberId,
        }).catch((err) => {
          console.error('WhatsApp send error:', err.message);
          return { sent: false, error: err.message };
        });
      }

      processed.push({
        type: 'customer_message',
        from: msg.from,
        replied: result.replied,
        reply: result.reply,
        orderNumber: result.order ? result.order.orderNumber : null,
        delivery,
      });
    }

    return processed;
  }

  // Meta WhatsApp Cloud API Webhook Receiver
  app.post('/webhook', async (req, res) => {
    const signature = req.headers['x-hub-signature-256'];
    if (!verifyMetaSignature(req.rawBody, signature)) {
      return res.sendStatus(401);
    }

    // Acknowledge immediately to Meta and process asynchronously
    res.sendStatus(200);

    try {
      await processMetaWebhookPayload(req.body, { dryRun: false });
    } catch (err) {
      console.error('Error processing Meta webhook:', err);
    }
  });

  // UI/Diagnostic Webhook Test (processes a Meta JSON payload synchronously in dryRun)
  app.post('/api/webhook-test', requireAdmin, async (req, res) => {
    try {
      const processed = await processMetaWebhookPayload(req.body, { dryRun: true });
      res.json({ ok: true, processed });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // Full App State for UI
  app.get('/api/state', (_req, res) => {
    const meta = getMetaConfig();
    const business = store.getBusiness();
    const menu = store.getMenu();
    const orders = store.getOrders();
    const convObj = store.getConversations();
    const conversations = Object.values(convObj).sort((a, b) =>
      String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''))
    );

    res.json({
      business,
      menu,
      orders,
      conversations,
      status: {
        metaConfigured: meta.configured,
        verifyToken: meta.verifyToken,
        appSecretSet: Boolean(meta.appSecret),
        graphVersion: meta.graphVersion,
        llmConfigured: isLlmConfigured(),
        llmModel: isLlmConfigured() ? process.env.LLM_MODEL || 'gpt-4o-mini' : 'Motor Local Inteligente',
        authRequired: Boolean((process.env.ADMIN_PASSWORD || '').trim()),
      },
    });
  });

  // Simulator Chat Endpoint
  app.post('/api/simulate', async (req, res) => {
    const { chatId = 'sim-cliente-1', text = '', profileName = 'Cliente de Prueba' } = req.body || {};
    if (!String(text).trim()) {
      return res.status(400).json({ error: 'El mensaje no puede estar vacío' });
    }
    try {
      const result = await handleIncomingMessage({
        store,
        chatId,
        text: String(text),
        customerPhone: '+56 9 0000 0000 (Simulador)',
        profileName,
        source: 'simulator',
      });
      res.json(result);
    } catch (err) {
      console.error('Simulate error:', err);
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/simulate/reset', (req, res) => {
    const { chatId = 'sim-cliente-1' } = req.body || {};
    const conv = store.resetConversation(chatId, {
      customerPhone: '+56 9 0000 0000 (Simulador)',
      profileName: 'Cliente de Prueba',
      source: 'simulator',
    });
    res.json({ ok: true, conversation: conv });
  });

  // Pause / Resume AI on a chat
  app.post('/api/conversations/:chatId/toggle-ai', requireAdmin, (req, res) => {
    const { chatId } = req.params;
    const conv = store.getConversation(chatId);
    const nextPaused =
      typeof req.body?.aiPaused === 'boolean' ? req.body.aiPaused : !conv.aiPaused;
    conv.aiPaused = nextPaused;
    if (!nextPaused) conv.aiPausedUntil = null;
    store.saveConversation(chatId, conv);
    res.json({ ok: true, conversation: conv });
  });

  // Manual human reply from Inbox
  app.post('/api/conversations/:chatId/manual-reply', requireAdmin, async (req, res) => {
    const { chatId } = req.params;
    const text = String(req.body?.text || '').trim();
    if (!text) return res.status(400).json({ error: 'Mensaje vacío' });

    const conv = store.getConversation(chatId);
    conv.messages.push({
      id: `owner_${Date.now()}`,
      sender: 'human_owner',
      text,
      timestamp: new Date().toISOString(),
    });
    // Pause AI automatically so owner takes over smoothly
    conv.aiPaused = true;
    store.saveConversation(chatId, conv);

    let whatsappDelivery = { sent: false, reason: 'simulator_chat' };
    if (conv.source === 'whatsapp') {
      try {
        whatsappDelivery = await sendWhatsAppText({
          to: conv.customerPhone || chatId,
          text,
        });
      } catch (err) {
        whatsappDelivery = { sent: false, error: err.message };
      }
    }

    res.json({ ok: true, conversation: conv, whatsappDelivery });
  });

  // Orders status management
  app.patch('/api/orders/:id', requireAdmin, (req, res) => {
    const { id } = req.params;
    const { status } = req.body || {};
    try {
      const updated = store.updateOrderStatus(id, status);
      if (!updated) return res.status(404).json({ error: 'Pedido no encontrado' });
      res.json({ ok: true, order: updated });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // Business config editor
  app.put('/api/business', requireAdmin, (req, res) => {
    const allowedFields = [
      'name',
      'whatsappNumber',
      'address',
      'hoursText',
      'prepTimeMinutes',
      'transferInstructions',
      'autoPauseOnHumanMinutes',
      'extraNotes',
    ];
    const patch = {};
    for (const key of allowedFields) {
      if (req.body && Object.prototype.hasOwnProperty.call(req.body, key)) {
        patch[key] = req.body[key];
      }
    }
    const updated = store.saveBusiness(patch);
    res.json({ ok: true, business: updated });
  });

  // Menu CRUD
  app.post('/api/menu', requireAdmin, (req, res) => {
    if (!req.body?.name) {
      return res.status(400).json({ error: 'El nombre del producto es obligatorio' });
    }
    const menu = store.upsertMenuItem(req.body);
    res.json({ ok: true, menu });
  });

  app.delete('/api/menu/:id', requireAdmin, (req, res) => {
    const menu = store.deleteMenuItem(req.params.id);
    res.json({ ok: true, menu });
  });

  return { app, store };
}

if (require.main === module) {
  const PORT = Number(process.env.PORT) || 3000;
  const { app } = createApp();
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Antojito caleño Bot escuchando en http://0.0.0.0:${PORT}`);
  });
}

module.exports = { createApp };
