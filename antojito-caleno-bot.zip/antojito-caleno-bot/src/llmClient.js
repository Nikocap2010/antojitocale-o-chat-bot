const { formatCLP } = require('./store');

function isLlmConfigured() {
  return Boolean(process.env.LLM_API_KEY && process.env.LLM_API_KEY.trim());
}

function buildSystemPrompt(business, menu, conv) {
  const availableItems = menu
    .filter((m) => m.available !== false)
    .map(
      (m) =>
        `- id="${m.id}" | ${m.name} | ${formatCLP(m.price)} (${m.price} CLP) | Cat: ${m.category} | Desc: ${m.description}`
    )
    .join('\n');

  const hoursInfo = business.hoursConfigured
    ? business.hoursText
    : 'NO CONFIGURADO (si preguntan, indica amablemente que confirmaremos el horario por este chat en un momento; NO inventes horarios)';

  const transferInfo = business.transferConfigured
    ? business.transferInstructions
    : 'NO CONFIGURADO AÚN (si eligen transferencia, indica que el local enviará los datos de transferencia por este mismo chat al revisar el pedido; NO inventes cuentas bancarias ni RUT)';

  const currentCart =
    (conv.state.cart || []).length > 0
      ? conv.state.cart.map((c) => `${c.quantity}x ${c.id}`).join(', ')
      : 'vacío';

  return `Eres el asistente de pedidos por WhatsApp de "${business.name}".
Reglas estrictas:
1. SOLO vende los productos disponibles en el menú listado abajo. NUNCA inventes productos, ingredientes ni precios.
2. Modalidad: ${business.fulfillmentLabel}. Dirección de retiro: ${business.address}. NO hay delivery.
3. Horario: ${hoursInfo}. Tiempo estimado de preparación: ${business.prepTimeMinutes || 20} minutos.
4. Medios de pago aceptados: Efectivo y Transferencia. Info transferencia: ${transferInfo}.
5. Si el cliente pide "salchipapa", "salchipapa grande", "papas" o "empanada" de forma ambigua y hay más de una opción disponible, NO agregues al carrito todavía: pregúntale cuál prefiere indicando los nombres y precios exactos.
6. Para confirmar un pedido necesitas: al menos 1 producto en el carrito, nombre del cliente para el retiro, medio de pago (efectivo o transferencia) y confirmación del cliente.
7. Responde en español chileno cercano, claro, breve (estilo WhatsApp) y sin inventar información.

MENÚ DISPONIBLE:
${availableItems}

ESTADO ACTUAL DEL PEDIDO:
- Carrito actual: ${currentCart}
- Nombre cliente: ${conv.state.customerName || 'pendiente'}
- Medio de pago: ${conv.state.paymentMethod || 'pendiente'}
- Notas: ${(conv.state.notes || []).join(', ') || 'ninguna'}

Responde ÚNICAMENTE con un objeto JSON válido con esta estructura:
{
  "addItems": [{"id": "id-del-menu", "quantity": 1}],
  "removeItems": [{"id": "id-del-menu", "quantity": 1}],
  "clearCart": false,
  "customerName": "",
  "paymentMethod": "",
  "cashNote": "",
  "notes": [],
  "confirmOrder": false,
  "pauseForHuman": false,
  "reply": "Tu respuesta por WhatsApp al cliente"
}`;
}

async function runLlmTurn({ userText, business, menu, conv }) {
  if (!isLlmConfigured()) return null;

  const baseUrl = (process.env.LLM_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
  const model = process.env.LLM_MODEL || 'gpt-4o-mini';
  const apiKey = process.env.LLM_API_KEY.trim();

  const recentMessages = (conv.messages || [])
    .slice(-10)
    .map((m) => ({
      role: m.sender === 'customer' ? 'user' : 'assistant',
      content: m.text,
    }));

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);

  try {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.2,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: buildSystemPrompt(business, menu, conv) },
          ...recentMessages,
          { role: 'user', content: userText },
        ],
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`LLM HTTP ${response.status}: ${errText.slice(0, 200)}`);
    }

    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) return null;

    const jsonMatch = content.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(jsonMatch ? jsonMatch[0] : content);
    return parsed;
  } catch (err) {
    console.warn('LLM fallback to local engine:', err.message);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

module.exports = {
  isLlmConfigured,
  runLlmTurn,
};
