const { formatCLP } = require('./store');

function normalizeText(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[¡!¿?.,;:()"]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const SPANISH_NUMBERS = {
  un: 1,
  una: 1,
  uno: 1,
  dos: 2,
  tres: 3,
  cuatro: 4,
  cinco: 5,
  seis: 6,
  'media docena': 6,
  siete: 7,
  ocho: 8,
  nueve: 9,
  diez: 10,
  once: 11,
  doce: 12,
  docena: 12,
};

function parseQuantityToken(token) {
  if (!token) return null;
  const clean = token.trim().toLowerCase();
  if (/^\d+$/.test(clean)) {
    const n = parseInt(clean, 10);
    return n > 0 && n <= 50 ? n : null;
  }
  const xMatch = clean.match(/^x(\d+)$/) || clean.match(/^(\d+)x$/);
  if (xMatch) {
    const n = parseInt(xMatch[1], 10);
    return n > 0 && n <= 50 ? n : null;
  }
  return SPANISH_NUMBERS[clean] || null;
}

function buildMenuText(menu, business) {
  const available = menu.filter((m) => m.available !== false);
  if (available.length === 0) {
    return 'Por el momento no tenemos productos disponibles en el menú.';
  }
  const byCategory = new Map();
  for (const item of available) {
    const cat = item.category || 'Menú';
    if (!byCategory.has(cat)) byCategory.set(cat, []);
    byCategory.get(cat).push(item);
  }

  const lines = [`🍽️ *Menú de ${business.name}*`, `📍 *Solo retiro en local:* ${business.address}`, ''];
  for (const [cat, items] of byCategory.entries()) {
    lines.push(`*${cat}*`);
    for (const item of items) {
      lines.push(`• *${item.name}*: ${formatCLP(item.price)}`);
      if (item.description && item.id.includes('especial')) {
        lines.push(`  _${item.description}_`);
      }
    }
    lines.push('');
  }
  lines.push(`💳 *Pagos:* Efectivo o Transferencia.`);
  lines.push(`¿Qué te gustaría pedir hoy?`);
  return lines.join('\n').trim();
}

function calculateCartTotals(cart, menu) {
  const menuMap = new Map(menu.map((m) => [m.id, m]));
  const validatedItems = [];
  let total = 0;
  for (const entry of cart || []) {
    const item = menuMap.get(entry.id);
    if (!item || item.available === false) continue;
    const qty = Math.max(1, Math.round(Number(entry.quantity) || 1));
    const subtotal = item.price * qty;
    total += subtotal;
    validatedItems.push({
      id: item.id,
      name: item.name,
      quantity: qty,
      unitPrice: item.price,
      subtotal,
    });
  }
  return { items: validatedItems, total };
}

function formatCartSummary(cart, menu) {
  const { items, total } = calculateCartTotals(cart, menu);
  if (items.length === 0) return 'Tu pedido está vacío.';
  const lines = items.map(
    (it) => `• ${it.quantity}x ${it.name} — ${formatCLP(it.subtotal)} (${formatCLP(it.unitPrice)} c/u)`
  );
  lines.push(`*Total:* ${formatCLP(total)}`);
  return lines.join('\n');
}

function getAvailableByIds(menu, ids) {
  const set = new Set(ids);
  return menu.filter((m) => set.has(m.id) && m.available !== false);
}

/**
 * Resolve pending ambiguous choice from customer's short reply
 */
function resolvePendingChoice(text, pendingChoice, menu) {
  if (!pendingChoice || !Array.isArray(pendingChoice.options) || pendingChoice.options.length === 0) {
    return null;
  }
  const norm = normalizeText(text);
  const availableOptions = pendingChoice.options
    .map((id) => menu.find((m) => m.id === id && m.available !== false))
    .filter(Boolean);

  if (availableOptions.length === 0) return null;

  // Check by price mention first ("4000", "4 mil", "12 mil", "1500", "2800", etc.)
  const priceMatches = availableOptions.filter((opt) => {
    const p = String(opt.price);
    const thousands = opt.price % 1000 === 0 ? String(opt.price / 1000) : null;
    return (
      norm.includes(p) ||
      (thousands && new RegExp(`\\b${thousands}\\s*(mil|lucas)\\b`).test(norm))
    );
  });
  if (priceMatches.length === 1) {
    return { item: priceMatches[0], quantity: pendingChoice.quantity || 1 };
  }

  // Specific pair & beverage helpers
  if (availableOptions.some((o) => o.id.includes('tradicional')) && availableOptions.some((o) => o.id.includes('especial'))) {
    if (norm.includes('tradicional') || norm.includes('normal') || norm.includes('simple') || norm.includes('clasica')) {
      const found = availableOptions.find((o) => o.id.includes('tradicional'));
      if (found) return { item: found, quantity: pendingChoice.quantity || 1 };
    }
    if (norm.includes('especial') || norm.includes('calena') || norm.includes('pollo') || norm.includes('costilla') || norm.includes('bbq') || norm.includes('completa')) {
      const found = availableOptions.find((o) => o.id.includes('especial'));
      if (found) return { item: found, quantity: pendingChoice.quantity || 1 };
    }
  }
  if (availableOptions.some((o) => o.id === 'empanada-queso') && availableOptions.some((o) => o.id === 'empanada-fritanga')) {
    if (norm.includes('queso')) {
      return { item: availableOptions.find((o) => o.id === 'empanada-queso'), quantity: pendingChoice.quantity || 1 };
    }
    if (norm.includes('fritanga') || norm.includes('colombiana') || norm.includes('carne')) {
      return { item: availableOptions.find((o) => o.id === 'empanada-fritanga'), quantity: pendingChoice.quantity || 1 };
    }
  }
  if (availableOptions.some((o) => o.id === 'papas-chicas') && availableOptions.some((o) => o.id === 'papas-grande')) {
    if (/\b(chica|chicas|pequena|pequenas)\b/.test(norm)) {
      return { item: availableOptions.find((o) => o.id === 'papas-chicas'), quantity: pendingChoice.quantity || 1 };
    }
    if (/\b(grande|grandes)\b/.test(norm)) {
      return { item: availableOptions.find((o) => o.id === 'papas-grande'), quantity: pendingChoice.quantity || 1 };
    }
  }
  if (availableOptions.some((o) => o.id === 'postobon-400ml') && availableOptions.some((o) => o.id === 'postobon-1-5l')) {
    if (/\b(400|400ml|chica|pequena|personal)\b/.test(norm)) {
      return { item: availableOptions.find((o) => o.id === 'postobon-400ml'), quantity: pendingChoice.quantity || 1 };
    }
    if (/\b(1\s*5|1\s*5l|litro y medio|litros|grande|familiar)\b/.test(norm)) {
      return { item: availableOptions.find((o) => o.id === 'postobon-1-5l'), quantity: pendingChoice.quantity || 1 };
    }
  }

  // Check by distinguishing keywords (3+ chars to allow "kem")
  const kwMatches = availableOptions.filter((opt) => {
    const optNorm = normalizeText(`${opt.name} ${(opt.aliases || []).join(' ')}`);
    const tokens = norm
      .split(' ')
      .filter((w) => w.length >= 3 && !['quiero', 'dame', 'para', 'esta', 'este', 'unas', 'unos', 'una', 'con', 'por'].includes(w));
    return tokens.some((tok) => new RegExp(`(?:^|\\s)${tok.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?:\\s|$)`).test(optNorm));
  });
  if (kwMatches.length === 1) {
    return { item: kwMatches[0], quantity: pendingChoice.quantity || 1 };
  }

  // Check explicit option index: "1", "la 1", "opcion 2", "primera", "segunda"
  const idxMap = {
    '1': 0,
    primera: 0,
    primero: 0,
    'la 1': 0,
    'el 1': 0,
    'opcion 1': 0,
    '2': 1,
    segunda: 1,
    segundo: 1,
    'la 2': 1,
    'el 2': 1,
    'opcion 2': 1,
    '3': 2,
    tercera: 2,
    tercero: 2,
    'la 3': 2,
    'opcion 3': 2,
    '4': 3,
    cuarta: 3,
    cuarto: 3,
    'la 4': 3,
    'opcion 4': 3,
    '5': 4,
    quinta: 4,
    'la 5': 4,
    'opcion 5': 4,
    '6': 5,
    sexta: 5,
    'la 6': 5,
    'opcion 6': 5,
  };
  for (const [key, idx] of Object.entries(idxMap)) {
    const regex = new RegExp(`(?:^|\\s)${key}(?:\\s|$)`);
    if (regex.test(norm) && availableOptions[idx]) {
      if (key === '1' && /\b1\s*(5|litro|litros|l|mil|000|lucas)\b/.test(norm)) continue;
      if (key === '4' && /\b4\s*(00|mil|000|lucas)\b/.test(norm)) continue;
      if (key === '2' && /\b2\s*(mil|000|lucas)\b/.test(norm)) continue;
      return { item: availableOptions[idx], quantity: pendingChoice.quantity || 1 };
    }
  }

  return null;
}

/**
 * Parse order additions, removals, and ambiguities from natural Spanish text
 */
function parseOrderActions(text, menu) {
  const norm = normalizeText(text);
  const available = menu.filter((m) => m.available !== false);

  const result = {
    action: 'add', // add | remove | clear
    additions: [],
    removals: [],
    ambiguous: [],
    notes: [],
  };

  // Detect full cart clear
  if (/\b(vaciar|borrar todo|limpiar pedido|empezar de nuevo|anular pedido|cancelar pedido|cancela el pedido)\b/.test(norm)) {
    result.action = 'clear';
    return result;
  }

  // Extract special food preparation notes ("sin lechuga", "sin cebolla", "extra salsa", etc.)
  const noteRegex = /\b((?:sin|con extra|extra|poca|sin nada de)\s+(?:lechuga|cebolla|salsa|salsas|mayo|mayonesa|ketchup|mostaza|aji|queso|tomate|palta|chicharron|pollo|costilla|salchicha|barbecue|bbq))\b/g;
  let nMatch;
  while ((nMatch = noteRegex.exec(norm)) !== null) {
    result.notes.push(nMatch[1]);
  }

  // Check if message is asking a question about menu/price rather than ordering
  const isPureQuestion =
    /\b(cuanto cuesta|cuanto sale|cuanto vale|a cuanto|que trae|que lleva|ingredientes|tienen|venden|hay)\b/.test(norm) &&
    !/\b(quiero|dame|deme|mandame|ponme|agrega|agregar|sumame|anota|pedir|pido|llevo|me das|traeme|necesito|para llevar|voy por)\b/.test(norm);

  if (isPureQuestion) {
    return result;
  }

  // Split by common separators ("y", ",", "+", "ademas", "tambien") while keeping segment context
  const segments = norm
    .replace(/\b(media docena)\b/g, '6')
    .replace(/\b(y tambien|ademas de|tambien quiero|y quiero|y dame|y me das|y)\b/g, '|')
    .replace(/\+/g, '|')
    .split('|')
    .map((s) => s.trim())
    .filter(Boolean);

  // Build explicit phrase matchers sorted longest-first
  const exactPhrases = [];
  for (const item of available) {
    const names = [normalizeText(item.name), ...(item.aliases || []).map(normalizeText)];
    for (const phrase of new Set(names)) {
      if (phrase) {
        exactPhrases.push({ phrase, item });
      }
    }
  }
  exactPhrases.sort((a, b) => b.phrase.length - a.phrase.length);

  for (const seg of segments) {
    const isRemovalSegment = /\b(quita|quitar|saca|sacar|elimina|eliminar|borra|borrar|resta|restar|no quiero|sin el|sin la|sin los|sin las)\b/.test(seg);
    let remaining = seg;

    // Helper to extract leading quantity right before phrase index
    function extractQtyBefore(str, matchIndex) {
      const prefix = str.slice(0, matchIndex).trim();
      const words = prefix.split(/\s+/).filter(Boolean);
      if (words.length === 0) return 1;
      const lastWord = words[words.length - 1];
      const q = parseQuantityToken(lastWord);
      return q || 1;
    }

    let matchedInSegment = false;
    // Scan for longest matching exact phrases in remaining text
    let guard = 0;
    while (guard++ < 8) {
      let best = null;
      for (const entry of exactPhrases) {
        const escaped = entry.phrase.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const rx = new RegExp(`(?:^|\\s)(${escaped})(?:\\s|$)`);
        const m = remaining.match(rx);
        if (m) {
          const idx = m.index + (m[0].startsWith(' ') ? 1 : 0);
          if (!best || entry.phrase.length > best.phrase.length || (entry.phrase.length === best.phrase.length && idx < best.idx)) {
            best = { ...entry, idx, matchLen: m[1].length };
          }
        }
      }
      if (!best) break;
      matchedInSegment = true;
      const qty = extractQtyBefore(remaining, best.idx);
      if (isRemovalSegment) {
        result.removals.push({ item: best.item, quantity: qty });
      } else {
        result.additions.push({ item: best.item, quantity: qty });
      }
      // Remove matched phrase and optional leading qty token from remaining
      remaining =
        remaining.slice(0, best.idx).trim() +
        ' ' +
        remaining.slice(best.idx + best.matchLen).trim();
      remaining = remaining.trim();
    }

    // Check ambiguous family terms in what's left of the segment (only for additions or single-family requests)
    if (!matchedInSegment) {
      // 1. "salchipapa grande"
      if (/\bsalchipapas?\s+grandes?\b/.test(seg)) {
        const opts = getAvailableByIds(menu, ['salchipapa-grande-tradicional', 'salchipapa-especial-grande']);
        if (opts.length === 1) {
          const qty = extractQtyBefore(seg, seg.search(/\bsalchipapas?\b/));
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          const qty = extractQtyBefore(seg, seg.search(/\bsalchipapas?\b/));
          result.ambiguous.push({
            family: 'Salchipapa Grande',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 2. "salchipapa especial" (o menciona ingredientes de la especial: pollo, costilla, bbq, barbicure)
      if (
        /\bsalchipapas?\s+especial(?:es)?\b/.test(seg) ||
        (/\bsalchipapas?\b/.test(seg) && /\b(pollo|costilla|bbq|barbecue|barbicure|papa hilo)\b/.test(seg))
      ) {
        const opts = getAvailableByIds(menu, ['salchipapa-especial-personal', 'salchipapa-especial-grande']);
        if (opts.length === 1) {
          const qty = extractQtyBefore(seg, seg.search(/\bsalchipapas?\b/));
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          const qty = extractQtyBefore(seg, seg.search(/\bsalchipapas?\b/));
          result.ambiguous.push({
            family: 'Salchipapa Especial',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 3. "salchipapa tradicional" (chica vs grande)
      if (/\bsalchipapas?\s+tradicional(?:es)?\b/.test(seg)) {
        const opts = getAvailableByIds(menu, ['salchipapa-chica-tradicional', 'salchipapa-grande-tradicional']);
        if (opts.length === 1) {
          const qty = extractQtyBefore(seg, seg.search(/\bsalchipapas?\b/));
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          const qty = extractQtyBefore(seg, seg.search(/\bsalchipapas?\b/));
          result.ambiguous.push({
            family: 'Salchipapa Tradicional',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 4. Generic "salchipapa"
      if (/\bsalchipapas?\b/.test(seg)) {
        const opts = getAvailableByIds(menu, [
          'salchipapa-chica-tradicional',
          'salchipapa-grande-tradicional',
          'salchipapa-especial-personal',
          'salchipapa-especial-grande',
        ]);
        const qty = extractQtyBefore(seg, seg.search(/\bsalchipapas?\b/));
        if (opts.length === 1) {
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          result.ambiguous.push({
            family: 'Salchipapa',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 5. Generic "papas" / "papas fritas"
      if (/\bpapas?(?:\s+fritas?)?\b/.test(seg)) {
        const opts = getAvailableByIds(menu, ['papas-chicas', 'papas-grande']);
        const qty = extractQtyBefore(seg, seg.search(/\bpapas?\b/));
        if (opts.length === 1) {
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          result.ambiguous.push({
            family: 'Papas Fritas',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 6. Generic "empanada" / "empanadas"
      if (/\bempanadas?\b/.test(seg)) {
        const opts = getAvailableByIds(menu, ['empanada-queso', 'empanada-fritanga']);
        const qty = extractQtyBefore(seg, seg.search(/\bempanadas?\b/));
        if (opts.length === 1) {
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          result.ambiguous.push({
            family: 'Empanada',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 7. Generic "postobon" (400 ml vs 1,5 Litros)
      if (/\bpostobon(?:es)?\b/.test(seg)) {
        const opts = getAvailableByIds(menu, ['postobon-400ml', 'postobon-1-5l']);
        const qty = extractQtyBefore(seg, seg.search(/\bpostobon(?:es)?\b/));
        if (opts.length === 1) {
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          result.ambiguous.push({
            family: 'Postobón',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 8. Generic "bebida de 1 litro" / "bebida de litro"
      if (/\bbebidas?\s+(?:de\s+)?(?:1\s*)?litros?\b/.test(seg)) {
        const opts = getAvailableByIds(menu, ['cocacola-1l', 'limon-soda-1l', 'kem-1l']);
        const qty = extractQtyBefore(seg, seg.search(/\bbebidas?\b/));
        if (opts.length === 1) {
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          result.ambiguous.push({
            family: 'Bebida de 1 Litro',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
        continue;
      }

      // 9. Generic "bebida" / "gaseosa"
      if (/\b(bebidas?|gaseosas?)\b/.test(seg)) {
        const opts = getAvailableByIds(menu, [
          'cocacola-1l',
          'limon-soda-1l',
          'kem-1l',
          'pony-malta',
          'postobon-400ml',
          'postobon-1-5l',
        ]);
        const qty = extractQtyBefore(seg, seg.search(/\b(bebidas?|gaseosas?)\b/));
        if (opts.length === 1) {
          result.additions.push({ item: opts[0], quantity: qty });
        } else if (opts.length > 1) {
          result.ambiguous.push({
            family: 'Bebida',
            quantity: qty,
            options: opts.map((o) => o.id),
          });
        }
      }
    }
  }

  return result;
}

function extractCheckoutFields(text, awaitingCheckoutName) {
  const raw = String(text || '').trim();
  const norm = normalizeText(raw);

  let paymentMethod = '';
  if (/\b(transferencia|transferir|transfiero|transf|cuenta rut|deposito)\b/.test(norm)) {
    paymentMethod = 'transferencia';
  } else if (/\b(efectivo|cash|billete|lucas|plata)\b/.test(norm)) {
    paymentMethod = 'efectivo';
  }

  let cashNote = '';
  const cashMatch = norm.match(/\b(?:pago con|con)\s*\$?\s*(\d{1,3}(?:[.,]\d{3})*|\d+)\s*(mil|lucas)?\b/);
  if (cashMatch) {
    let val = parseInt(cashMatch[1].replace(/[.,]/g, ''), 10);
    if (cashMatch[2] || (val > 0 && val <= 100)) {
      val = val * 1000;
    }
    if (val >= 1000) {
      cashNote = `Paga con ${formatCLP(val)}`;
      if (!paymentMethod) paymentMethod = 'efectivo';
    }
  }

  let customerName = '';
  const namePatterns = [
    /(?:a nombre de|mi nombre es|me llamo|soy)\s+([a-zA-ZáéíóúñÁÉÍÓÚÑ]+(?:\s+[a-zA-ZáéíóúñÁÉÍÓÚÑ]+)?)/i,
    /(?:nombre)\s*[:\-]\s*([a-zA-ZáéíóúñÁÉÍÓÚÑ]+(?:\s+[a-zA-ZáéíóúñÁÉÍÓÚÑ]+)?)/i,
  ];
  for (const pat of namePatterns) {
    const m = raw.match(pat);
    if (m && m[1]) {
      // Trim trailing payment/filler words captured accidentally
      const cleaned = m[1]
        .replace(/\b(y|con|pago|en|efectivo|transferencia|por|favor|gracias|para|retirar)\b.*$/i, '')
        .trim();
      if (cleaned.length >= 2) {
        customerName = cleaned;
        break;
      }
    }
  }

  // If bot specifically asked for name during checkout and user replied shortly (e.g. "Camila, transferencia" or "Juan Perez")
  if (!customerName && awaitingCheckoutName) {
    let candidate = raw
      .replace(/\b(hola|buenas|solo eso|eso nomas|eso no mas|nada mas|confirmo|confirmar|si|sí|dale|listo|ok|gracias|por favor|pago en|pago con|en|con|efectivo|transferencia|transferir|retiro)\b/gi, ' ')
      .replace(/\$?\s*\d+(?:[.,]\d+)?\s*(?:mil|lucas)?/gi, ' ')
      .replace(/[,.\-!?]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (
      candidate.length >= 2 &&
      candidate.length <= 35 &&
      /^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s]+$/.test(candidate) &&
      candidate.split(' ').length <= 3
    ) {
      customerName = candidate;
    }
  }

  if (customerName) {
    customerName = customerName
      .split(/\s+/)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      .join(' ');
  }

  const wantsToConfirm =
    /\b(confirmo|confirmar|eso nomas|eso no mas|nada mas|solo eso|cerrar pedido|listo el pedido|listo|asi esta bien|esta bien|dale|si por favor|si dale|si gracias|envia el pedido|enviar pedido)\b/.test(
      norm
    ) ||
    /^(si|sí|ok|dale|listo|ya|perfecto)$/.test(norm);

  return {
    paymentMethod,
    cashNote,
    customerName,
    wantsToConfirm,
  };
}

function detectIntent(text) {
  const norm = normalizeText(text);
  return {
    isGreeting: /^(hola+|buenas|buen dia|buenos dias|buenas tardes|buenas noches|holi|ola|alo|aló)\b/.test(norm),
    asksMenu: /\b(menu|carta|lista|precios|valores|que tienen|que venden|productos|catalogo|catálogo|cuanto cuestan|cuanto cuesta|cuanto valen|cuanto vale|cuanto sale|cuanto salen|a cuanto)\b/.test(norm),
    asksDrinks: /\b(que bebidas|tienen bebidas|venden bebidas|hay bebidas|bebidas tienen|que gaseosas|para tomar)\b/.test(norm),
    asksLocation: /\b(donde quedan|donde estan|donde están|direccion|dirección|ubicacion|ubicación|como llegar|donde retiro|donde se retira|local)\b/.test(norm),
    asksDelivery: /\b(delivery|despacho|envio|envío|reparto|domicilio|llevan a|mandan a)\b/.test(norm),
    asksHours: /\b(horario|horarios|que hora abren|que hora cierran|hasta que hora|estan abiertos|están abiertos|atienden hoy)\b/.test(norm),
    asksPayment: /\b(medios de pago|formas de pago|como pago|como se paga|aceptan tarjeta|tarjeta|debito|débito|credito|crédito|webpay|transferencia|efectivo|datos de transferencia|cuenta)\b/.test(norm),
    asksIngredients: /\b(que trae|que lleva|ingredientes|contenido|como es la salchipapa|barbecue|barbicure|costilla|aborrajado)\b/.test(norm),
    asksOrderStatus: /\b(ver pedido|mi pedido|como va|cuanto va|resumen|carrito)\b/.test(norm),
    asksHuman: /\b(humano|persona|hablar con alguien|alguien real|atencion personal|reclamo|problema con|encargado)\b/.test(norm),
  };
}

module.exports = {
  normalizeText,
  buildMenuText,
  calculateCartTotals,
  formatCartSummary,
  resolvePendingChoice,
  parseOrderActions,
  extractCheckoutFields,
  detectIntent,
};
