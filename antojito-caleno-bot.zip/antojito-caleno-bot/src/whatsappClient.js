const crypto = require('node:crypto');

// Deduplicate webhook message IDs across Meta retries
const seenMessageIds = new Map();
const DEDUP_TTL_MS = 10 * 60 * 1000;

function isDuplicateMessage(messageId) {
  if (!messageId) return false;
  const now = Date.now();
  // Clean expired entries occasionally
  if (seenMessageIds.size > 500) {
    for (const [id, ts] of seenMessageIds.entries()) {
      if (now - ts > DEDUP_TTL_MS) seenMessageIds.delete(id);
    }
  }
  if (seenMessageIds.has(messageId)) {
    return true;
  }
  seenMessageIds.set(messageId, now);
  return false;
}

function getMetaConfig() {
  const accessToken = (process.env.META_ACCESS_TOKEN || '').trim();
  const phoneNumberId = (process.env.META_PHONE_NUMBER_ID || '').trim();
  const verifyToken = (process.env.META_VERIFY_TOKEN || 'antojito_caleno_verify_2026').trim();
  const appSecret = (process.env.META_APP_SECRET || '').trim();
  const graphVersion = (process.env.META_GRAPH_VERSION || 'v22.0').trim();

  return {
    accessToken,
    phoneNumberId,
    verifyToken,
    appSecret,
    graphVersion,
    configured: Boolean(accessToken && phoneNumberId),
  };
}

function verifyMetaSignature(rawBody, signatureHeader) {
  const { appSecret } = getMetaConfig();
  if (!appSecret) {
    // Signature validation skipped when META_APP_SECRET is not set
    return true;
  }
  if (!signatureHeader || !rawBody) return false;
  const expected =
    'sha256=' + crypto.createHmac('sha256', appSecret).update(rawBody).digest('hex');

  const a = Buffer.from(signatureHeader);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

function extractMessageText(msg) {
  if (!msg) return { text: '', supported: false, mediaType: 'unknown' };
  if (msg.type === 'text' && msg.text?.body) {
    return { text: msg.text.body, supported: true, mediaType: 'text' };
  }
  if (msg.type === 'interactive') {
    const btnTitle = msg.interactive?.button_reply?.title;
    const listTitle = msg.interactive?.list_reply?.title;
    if (btnTitle || listTitle) {
      return { text: btnTitle || listTitle, supported: true, mediaType: 'interactive' };
    }
  }
  if (msg.type === 'button' && msg.button?.text) {
    return { text: msg.button.text, supported: true, mediaType: 'button' };
  }
  return { text: '', supported: false, mediaType: msg.type || 'unknown' };
}

function extractWebhookEvents(payload) {
  const customerMessages = [];
  const ownerEchoes = [];

  if (!payload || payload.object !== 'whatsapp_business_account') {
    return { customerMessages, ownerEchoes };
  }

  for (const entry of payload.entry || []) {
    for (const change of entry.changes || []) {
      const value = change.value || {};
      const phoneNumberId = value.metadata?.phone_number_id || '';
      const contacts = value.contacts || [];

      // Standard incoming messages from customers
      for (const msg of value.messages || []) {
        if (isDuplicateMessage(msg.id)) continue;
        const contact = contacts.find((c) => c.wa_id === msg.from) || contacts[0];
        const parsed = extractMessageText(msg);
        customerMessages.push({
          messageId: msg.id,
          from: msg.from,
          profileName: contact?.profile?.name || '',
          phoneNumberId,
          timestamp: msg.timestamp,
          ...parsed,
        });
      }

      // WhatsApp Coexistence echoes (when owner sends a manual message from the phone app)
      const echoes = value.smb_message_echoes || [];
      for (const echo of echoes) {
        if (isDuplicateMessage(echo.id)) continue;
        const parsed = extractMessageText(echo);
        if (echo.to && parsed.text) {
          ownerEchoes.push({
            messageId: echo.id,
            to: echo.to,
            text: parsed.text,
            phoneNumberId,
            timestamp: echo.timestamp,
          });
        }
      }
    }
  }

  return { customerMessages, ownerEchoes };
}

async function sendWhatsAppText({ to, text, phoneNumberId }) {
  const cfg = getMetaConfig();
  const targetPhoneId = phoneNumberId || cfg.phoneNumberId;

  if (!cfg.accessToken || !targetPhoneId) {
    return {
      sent: false,
      reason: 'meta_not_configured',
      previewPayload: {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to,
        type: 'text',
        text: { body: text },
      },
    };
  }

  const url = `https://graph.facebook.com/${cfg.graphVersion}/${targetPhoneId}/messages`;
  const cleanText = String(text || '').slice(0, 4096);

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cfg.accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to,
      type: 'text',
      text: {
        preview_url: false,
        body: cleanText,
      },
    }),
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(`Meta Graph API error (${response.status}): ${JSON.stringify(data)}`);
  }

  return {
    sent: true,
    messageId: data?.messages?.[0]?.id || null,
    raw: data,
  };
}

async function markWhatsAppRead({ messageId, phoneNumberId }) {
  const cfg = getMetaConfig();
  const targetPhoneId = phoneNumberId || cfg.phoneNumberId;
  if (!cfg.accessToken || !targetPhoneId || !messageId) return;

  const url = `https://graph.facebook.com/${cfg.graphVersion}/${targetPhoneId}/messages`;
  await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cfg.accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      status: 'read',
      message_id: messageId,
    }),
  }).catch((err) => {
    console.warn('Could not mark message as read:', err.message);
  });
}

module.exports = {
  getMetaConfig,
  verifyMetaSignature,
  extractWebhookEvents,
  sendWhatsAppText,
  markWhatsAppRead,
};
